# Frontend Integration Guide

This document provides guidance on integrating the Next.js frontend with the Express backend API.

## Configuration

### Update Environment Variables

In your Next.js frontend project, create or update the `.env.local` file:

```
# API Configuration
NEXT_PUBLIC_API_URL=http://localhost:5000/api/v1
```

## Authentication Integration

### Creating an API Client

Create a utility file for API calls in `frontend/lib/api.js`:

```javascript
import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL;

// Create axios instance
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Request interceptor for adding the auth token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default apiClient;
```

### Authentication Hooks

Create authentication hooks in `frontend/hooks/useAuth.js`:

```javascript
import { useState, useEffect, createContext, useContext } from "react";
import { useRouter } from "next/router";
import apiClient from "@/lib/api";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  // Check if user is logged in
  useEffect(() => {
    const checkUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (token) {
          const res = await apiClient.get("/auth/current-user");
          setUser(res.data.data);
        }
      } catch (error) {
        localStorage.removeItem("token");
      } finally {
        setLoading(false);
      }
    };

    checkUser();
  }, []);

  // Register user
  const register = async (userData) => {
    try {
      const res = await apiClient.post("/auth/register", userData);
      localStorage.setItem("token", res.data.data.token);
      setUser(res.data.data);
      return res.data;
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || "Registration failed",
      };
    }
  };

  // Login user
  const login = async (credentials) => {
    try {
      const res = await apiClient.post("/auth/login", credentials);
      localStorage.setItem("token", res.data.data.token);
      setUser(res.data.data);
      return res.data;
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || "Login failed",
      };
    }
  };

  // Logout user
  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    router.push("/");
  };

  return (
    <AuthContext.Provider value={{ user, loading, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
```

### Protecting Routes

Create a component to protect authenticated routes in `frontend/components/ProtectedRoute.js`:

```javascript
import { useRouter } from "next/router";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";

export default function ProtectedRoute({ children, userTypes = null }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.push("/login");
      } else if (userTypes && !userTypes.includes(user.userType)) {
        router.push("/unauthorized");
      }
    }
  }, [user, loading, router, userTypes]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    return null;
  }

  if (userTypes && !userTypes.includes(user.userType)) {
    return null;
  }

  return <>{children}</>;
}
```

## API Services

### Scholarship Service

Create a service for scholarship-related API calls in `frontend/services/scholarshipService.js`:

```javascript
import apiClient from "@/lib/api";

// Get all scholarships
export const getAllScholarships = async () => {
  try {
    const res = await apiClient.get("/scholarships");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch scholarships",
    };
  }
};

// Get scholarship by ID
export const getScholarshipById = async (id) => {
  try {
    const res = await apiClient.get(`/scholarships/${id}`);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch scholarship",
    };
  }
};

// Create scholarship (company only)
export const createScholarship = async (scholarshipData) => {
  try {
    const res = await apiClient.post("/scholarships", scholarshipData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to create scholarship",
    };
  }
};

// Update scholarship (company only)
export const updateScholarship = async (id, scholarshipData) => {
  try {
    const res = await apiClient.put(`/scholarships/${id}`, scholarshipData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to update scholarship",
    };
  }
};

// Delete scholarship (company only)
export const deleteScholarship = async (id) => {
  try {
    const res = await apiClient.delete(`/scholarships/${id}`);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to delete scholarship",
    };
  }
};

// Get company scholarships (company only)
export const getCompanyScholarships = async () => {
  try {
    const res = await apiClient.get("/scholarships/company/all");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message:
        error.response?.data?.message || "Failed to fetch company scholarships",
    };
  }
};
```

### Application Service

Create a service for application-related API calls in `frontend/services/applicationService.js`:

```javascript
import apiClient from "@/lib/api";

// Start application (student only)
export const startApplication = async (scholarshipId) => {
  try {
    const res = await apiClient.post("/applications/start", { scholarshipId });
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to start application",
    };
  }
};

// Submit application (student only)
export const submitApplication = async (applicationData) => {
  try {
    const res = await apiClient.post("/applications", applicationData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to submit application",
    };
  }
};

// Get student applications (student only)
export const getStudentApplications = async () => {
  try {
    const res = await apiClient.get("/applications");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch applications",
    };
  }
};

// Get company applications (company only)
export const getCompanyApplications = async () => {
  try {
    const res = await apiClient.get("/applications/company");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch applications",
    };
  }
};

// Get application by ID
export const getApplicationById = async (id) => {
  try {
    const res = await apiClient.get(`/applications/${id}`);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch application",
    };
  }
};

// Update application status (company only)
export const updateApplicationStatus = async (id, statusData) => {
  try {
    const res = await apiClient.put(`/applications/${id}/status`, statusData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message:
        error.response?.data?.message || "Failed to update application status",
    };
  }
};
```

### Profile Service

Create a service for profile-related API calls in `frontend/services/profileService.js`:

```javascript
import apiClient from "@/lib/api";

// Get student profile (student only)
export const getStudentProfile = async () => {
  try {
    const res = await apiClient.get("/profiles/student");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch profile",
    };
  }
};

// Update student profile (student only)
export const updateStudentProfile = async (profileData) => {
  try {
    const res = await apiClient.put("/profiles/student", profileData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to update profile",
    };
  }
};

// Get company profile (company only)
export const getCompanyProfile = async () => {
  try {
    const res = await apiClient.get("/profiles/company");
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to fetch profile",
    };
  }
};

// Update company profile (company only)
export const updateCompanyProfile = async (profileData) => {
  try {
    const res = await apiClient.put("/profiles/company", profileData);
    return res.data;
  } catch (error) {
    return {
      success: false,
      message: error.response?.data?.message || "Failed to update profile",
    };
  }
};
```

## Using the Services in Components

### Example: Scholarship Listing Page

```jsx
import { useState, useEffect } from "react";
import { getAllScholarships } from "@/services/scholarshipService";

export default function ScholarshipsPage() {
  const [scholarships, setScholarships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchScholarships = async () => {
      try {
        const result = await getAllScholarships();
        if (result.success) {
          setScholarships(result.data);
        } else {
          setError(result.message);
        }
      } catch (err) {
        setError("An unexpected error occurred");
      } finally {
        setLoading(false);
      }
    };

    fetchScholarships();
  }, []);

  if (loading) return <div>Loading scholarships...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h1>Available Scholarships</h1>
      {scholarships.length === 0 ? (
        <p>No scholarships found</p>
      ) : (
        <ul>
          {scholarships.map((scholarship) => (
            <li key={scholarship.id}>
              <h2>{scholarship.title}</h2>
              <p>Amount: ${scholarship.amount}</p>
              <p>
                Deadline: {new Date(scholarship.deadline).toLocaleDateString()}
              </p>
              <p>Provider: {scholarship.company_name}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
```

## Handling Form Submissions

### Example: Login Form

```jsx
import { useState } from "react";
import { useRouter } from "next/router";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { login } = useAuth();
  const router = useRouter();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await login(credentials);
      if (result.success) {
        router.push("/dashboard");
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError("An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Login</h1>
      {error && <div className="error">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={credentials.email}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={credentials.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </div>
  );
}
```

## Setting Up AuthProvider

In your `_app.js` file, wrap your application with the AuthProvider:

```jsx
import { AuthProvider } from "@/hooks/useAuth";
import "@/styles/globals.css";

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <Component {...pageProps} />
    </AuthProvider>
  );
}
```

## Wrapping Up

This integration guide provides the foundation for connecting your Next.js frontend to the Express backend API. The key components are:

1. API client configuration
2. Authentication context and hooks
3. Service modules for each API domain
4. Protected routes for authenticated pages
5. Example components demonstrating API usage

By following this structure, you'll have a clean and maintainable way to interact with your backend API while keeping authentication state consistent throughout your application.
