const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Get student profile
// @route   GET /api/v1/profiles/student
// @access  Private/Student
exports.getStudentProfile = async (req, res) => {
  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    // If no profile exists, return empty profile
    if (studentProfiles.length === 0) {
      return res.status(200).json({
        success: true,
        data: null,
      });
    }

    const studentId = studentProfiles[0].id;

    // Get education details
    const educationDetails = await query(
      "SELECT * FROM student_education WHERE student_id = $1",
      [studentId]
    );

    // Get achievements
    const achievements = await query(
      "SELECT * FROM student_achievements WHERE student_id = $1",
      [studentId]
    );

    res.status(200).json({
      success: true,
      data: {
        profile: studentProfiles[0],
        education: educationDetails.length > 0 ? educationDetails[0] : null,
        achievements: achievements.length > 0 ? achievements[0] : null,
      },
    });
  } catch (error) {
    console.error("Get student profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create/Update student profile
// @route   PUT /api/v1/profiles/student
// @access  Private/Student
exports.updateStudentProfile = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const {
      firstName,
      lastName,
      phone,
      dob,
      gender,
      address,
      education,
      achievements,
    } = req.body;

    // Check if profile exists
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    let studentId;

    if (studentProfiles.length === 0) {
      // Create profile
      const result = await query(
        `INSERT INTO student_profiles 
         (user_id, first_name, last_name, phone, dob, gender, address) 
         VALUES ($1, $2, $3, $4, $5, $6, $7) 
         RETURNING id`,
        [req.user.id, firstName, lastName, phone, dob, gender, address]
      );
      studentId = result[0].id;
    } else {
      // Update profile
      studentId = studentProfiles[0].id;
      await query(
        `UPDATE student_profiles 
         SET first_name = $1, last_name = $2, phone = $3, dob = $4, 
             gender = $5, address = $6, updated_at = CURRENT_TIMESTAMP 
         WHERE id = $7`,
        [firstName, lastName, phone, dob, gender, address, studentId]
      );
    }

    // Handle education details
    if (education) {
      const educationDetails = await query(
        "SELECT * FROM student_education WHERE student_id = $1",
        [studentId]
      );

      if (educationDetails.length === 0) {
        // Create education record
        await query(
          `INSERT INTO student_education 
           (student_id, current_school, degree, major, gpa, graduation_date, previous_education) 
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [
            studentId,
            education.currentSchool,
            education.degree,
            education.major,
            education.gpa,
            education.graduationDate,
            education.previousEducation,
          ]
        );
      } else {
        // Update education record
        await query(
          `UPDATE student_education 
           SET current_school = $1, degree = $2, major = $3, 
               gpa = $4, graduation_date = $5, previous_education = $6, 
               updated_at = CURRENT_TIMESTAMP 
           WHERE student_id = $7`,
          [
            education.currentSchool,
            education.degree,
            education.major,
            education.gpa,
            education.graduationDate,
            education.previousEducation,
            studentId,
          ]
        );
      }
    }

    // Handle achievements
    if (achievements) {
      const achievementRecords = await query(
        "SELECT * FROM student_achievements WHERE student_id = $1",
        [studentId]
      );

      if (achievementRecords.length === 0) {
        // Create achievements record
        await query(
          `INSERT INTO student_achievements 
           (student_id, awards, activities, work_experience, skills) 
           VALUES ($1, $2, $3, $4, $5)`,
          [
            studentId,
            achievements.awards,
            achievements.activities,
            achievements.workExperience,
            achievements.skills,
          ]
        );
      } else {
        // Update achievements record
        await query(
          `UPDATE student_achievements 
           SET awards = $1, activities = $2, work_experience = $3, 
               skills = $4, updated_at = CURRENT_TIMESTAMP 
           WHERE student_id = $5`,
          [
            achievements.awards,
            achievements.activities,
            achievements.workExperience,
            achievements.skills,
            studentId,
          ]
        );
      }
    }

    res.status(200).json({
      success: true,
      message: "Student profile updated successfully",
    });
  } catch (error) {
    console.error("Update student profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company profile
// @route   GET /api/v1/profiles/company
// @access  Private/Company
exports.getCompanyProfile = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    // If no profile exists, return empty profile
    if (companyProfiles.length === 0) {
      return res.status(200).json({
        success: true,
        data: null,
      });
    }

    res.status(200).json({
      success: true,
      data: companyProfiles[0],
    });
  } catch (error) {
    console.error("Get company profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create/Update company profile
// @route   PUT /api/v1/profiles/company
// @access  Private/Company
exports.updateCompanyProfile = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const { companyName, website, contactName, industry, description } =
      req.body;

    // Check if profile exists
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      // Create profile
      await query(
        `INSERT INTO company_profiles 
         (user_id, company_name, website, contact_name, industry, description) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [req.user.id, companyName, website, contactName, industry, description]
      );
    } else {
      // Update profile
      await query(
        `UPDATE company_profiles 
         SET company_name = $1, website = $2, contact_name = $3, 
             industry = $4, description = $5, updated_at = CURRENT_TIMESTAMP 
         WHERE user_id = $6`,
        [companyName, website, contactName, industry, description, req.user.id]
      );
    }

    res.status(200).json({
      success: true,
      message: "Company profile updated successfully",
    });
  } catch (error) {
    console.error("Update company profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};
