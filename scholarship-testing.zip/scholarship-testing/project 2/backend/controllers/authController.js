// backend/controllers/authController.js
const { query } = require('../config/db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

/**
 * Helper function to hash password
 */
const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

/**
 * Register a new user
 * @route POST /api/v1/auth/register
 * @access Public
 */
exports.register = async (req, res) => {
  try {
    const { name, email, password, userType } = req.body;

    // Validation
    if (!name || !email || !password || !userType) {
      return res.status(400).json({
        success: false,
        message: "Please provide name, email, password, and userType"
      });
    }

    // Check if email already exists
    const existingUser = await query('SELECT * FROM users WHERE email = $1', [email]);
    
    if (existingUser && existingUser.length > 0) {
      return res.status(400).json({
        success: false,
        message: "User with this email already exists"
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create user
    const newUser = await query(
      'INSERT INTO users (email, password_hash, name, user_type) VALUES ($1, $2, $3, $4) RETURNING id, email, name, user_type',
      [email, hashedPassword, name, userType]
    );

    // Generate JWT token
    const token = generateToken(newUser[0].id, userType);

    // Return success with token
    res.status(201).json({
      success: true,
      data: {
        id: newUser[0].id,
        name: newUser[0].name,
        email: newUser[0].email,
        userType: newUser[0].user_type,
        token
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Server error during registration",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

/**
 * Login user
 * @route POST /api/v1/auth/login
 * @access Public
 */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Please provide email and password"
      });
    }

    // Find user by email
    const users = await query('SELECT * FROM users WHERE email = $1', [email]);
    
    if (!users || users.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials"
      });
    }

    const user = users[0];

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials"
      });
    }

    // Generate token
    const token = generateToken(user.id, user.user_type);

    // Return success with token
    res.status(200).json({
      success: true,
      data: {
        id: user.id,
        name: user.name,
        email: user.email,
        userType: user.user_type,
        token
      }
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during login",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

/**
 * Get current logged in user
 * @route GET /api/v1/auth/current-user
 * @access Private
 */
exports.getCurrentUser = async (req, res) => {
  try {
    // User is already available from the auth middleware
    const user = await query('SELECT id, email, name, user_type FROM users WHERE id = $1', [req.user.id]);

    if (!user || user.length === 0) {
      return res.status(404).json({
        success: false,
        message: "User not found"
      });
    }

    res.status(200).json({
      success: true,
      data: {
        id: user[0].id,
        email: user[0].email,
        name: user[0].name,
        userType: user[0].user_type
      }
    });
  } catch (error) {
    console.error("Get current user error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

/**
 * Generate JWT token
 * @param {number} id - User ID
 * @param {string} userType - User type (student/company)
 * @returns {string} JWT token
 */
const generateToken = (id, userType) => {
  return jwt.sign(
    { id, user_type: userType },
    process.env.JWT_SECRET || 'test-jwt-secret',
    { expiresIn: '30d' }
  );
};