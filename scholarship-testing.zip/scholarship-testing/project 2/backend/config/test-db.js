// backend/config/test-db.js
const { neon } = require("@neondatabase/serverless");

// Create a mock database client with detailed response handling
const mockClient = {
  query: jest.fn().mockImplementation(async (queryText, params = []) => {
    console.log(`Mock DB Query: ${queryText}`);
    console.log('Query params:', params);
    
    // Handle user registration/login queries
    if (queryText.includes('SELECT * FROM users WHERE email =')) {
      const email = params[0];
      console.log(`Checking if user exists: ${email}`);
      
      // For specific test emails used in tests, return empty array (user doesn't exist)
      if (email === 'test@example.com' || 
          email === 'student@example.com' || 
          email === 'company@example.com' ||
          email === 'profile_student@example.com' ||
          email === 'profile_company@example.com' ||
          email === 'app_student@example.com' ||
          email === 'app_company@example.com') {
        console.log(`User ${email} doesn't exist yet (for registration)`);
        return [];
      }
      
      // For other emails, return a mock user for login tests
      return [{
        id: 1,
        email: email,
        password_hash: '$2a$10$xVqYAYPU8B2VPRzfSKAGEORR3TgYKOoRYAxPEP8/w2ytZg00H8212', // hashed 'password123'
        name: 'Test User',
        user_type: email.includes('company') ? 'company' : 'student'
      }];
    }
    
    // Handle user insertion
    if (queryText.includes('INSERT INTO users')) {
      console.log('Creating new user');
      // Return mock user with ID
      return [{
        id: Math.floor(Math.random() * 1000) + 1, // Random ID to ensure uniqueness
        email: params[0], // Email should be first param
        name: params[2], // Name should be third param
        user_type: params[3] // userType should be fourth param
      }];
    }
    
    // Handle profile queries
    if (queryText.includes('SELECT * FROM student_profiles WHERE user_id =')) {
      console.log('Getting student profile');
      // Return mock student profile or empty for creation
      return [{
        id: 1,
        user_id: params[0],
        first_name: 'Test',
        last_name: 'Student',
        phone: '123-456-7890'
      }];
    }
    
    if (queryText.includes('SELECT * FROM company_profiles WHERE user_id =')) {
      console.log('Getting company profile');
      // Return mock company profile or empty for creation
      return [{
        id: 1,
        user_id: params[0],
        company_name: 'Test Company',
        industry: 'Technology',
        contact_name: 'Test Contact'
      }];
    }
    
    if (queryText.includes('INSERT INTO student_profiles') || 
        queryText.includes('UPDATE student_profiles')) {
      console.log('Creating/updating student profile');
      return [{ id: 1 }];
    }
    
    if (queryText.includes('INSERT INTO company_profiles') || 
        queryText.includes('UPDATE company_profiles')) {
      console.log('Creating/updating company profile');
      return [{ id: 1 }];
    }
    
    // Handle scholarship queries
    if (queryText.includes('SELECT s.*, cp.company_name FROM scholarships s')) {
      console.log('Getting all scholarships');
      return [{
        id: 1,
        company_id: 1,
        title: 'Test Scholarship',
        amount: 1000,
        description: 'Test description',
        open_date: '2025-01-01',
        deadline: '2025-12-31',
        recipients_count: 1,
        status: 'active',
        company_name: 'Test Company'
      }];
    }
    
    if (queryText.includes('INSERT INTO scholarships')) {
      console.log('Creating scholarship');
      return [{ id: 999 }]; // Use a consistent ID for testing
    }
    
    if (queryText.includes('SELECT * FROM scholarships WHERE id =')) {
      console.log('Getting scholarship by ID');
      return [{
        id: params[0],
        company_id: 1,
        title: 'Test Scholarship',
        amount: 1000,
        description: 'Test description',
        open_date: '2025-01-01',
        deadline: '2025-12-31',
        recipients_count: 1,
        status: 'active'
      }];
    }
    
    // Handle application queries
    if (queryText.includes('INSERT INTO applications')) {
      console.log('Creating application');
      return [{ id: 888 }]; // Use a consistent ID for testing
    }
    
    if (queryText.includes('SELECT * FROM applications')) {
      console.log('Getting applications');
      return [{
        id: 888,
        scholarship_id: 999,
        student_id: 1,
        status: 'submitted',
        essay_response: 'Test essay',
        documents_urls: ['http://example.com/doc']
      }];
    }
    
    // Default for other queries - return empty array
    console.log('Unhandled query, returning empty array');
    return [];
  })
};

// Check if we're in a unit test environment
const isUnitTest = process.env.TEST_TYPE === 'unit';

// For tests, use the mock client
const sql = mockClient;
console.log(`Using ${isUnitTest ? 'unit' : 'integration'} test database (mock)`);

// Change this part in your test-db.js mock database to always ensure results are arrays

async function query(queryText, params = []) {
  try {
    // If using mock client, customize responses based on the query
    const results = await sql.query(queryText, params);
    
    // Always ensure we return an array
    return Array.isArray(results) ? results : [];
  } catch (error) {
    console.error("Database query error:", error);
    throw error;
  }
}

module.exports = {
  query,
  sql,
  mockClient
};