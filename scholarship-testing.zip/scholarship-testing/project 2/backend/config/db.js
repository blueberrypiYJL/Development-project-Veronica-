const { neon } = require("@neondatabase/serverless");

// Create a SQL client with the database URL from environment variables
const sql = neon("postgresql://ezitech_owner:UlDiCjQb0z4y@ep-proud-sky-a5zan17i-pooler.us-east-2.aws.neon.tech/ezitech?sslmode=require");

// Helper function to execute a query and return the results
async function query(queryText, params = []) {
  try {
    return await sql.query(queryText, params);
  } catch (error) {
    console.error("Database query error:", error);
    throw error;
  }
}

module.exports = {
  query,
  sql,
};
