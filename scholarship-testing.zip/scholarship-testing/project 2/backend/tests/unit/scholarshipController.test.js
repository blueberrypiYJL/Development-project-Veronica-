// backend/tests/unit/scholarshipController.test.js
const scholarshipController = require('../../controllers/scholarshipController');
const { query } = require('../../config/db');

// Set unit test mode
process.env.TEST_TYPE = 'unit';

// Mock the database
jest.mock('../../config/db', () => {
  // Get the test-db configuration which has our mockClient
  const testDb = require('../../config/test-db');
  return {
    ...testDb,
    query: jest.fn()
  };
});

describe('Scholarship Controller', () => {
  // Mock request and response objects
  let req, res;
  
  beforeEach(() => {
    req = {
      params: {},
      body: {},
      user: {
        id: 1,
        user_type: 'company'
      }
    };
    res = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn()
    };
    
    // Clear all mocks between tests
    jest.clearAllMocks();
  });

  test('getAllScholarships should return scholarships', async () => {
    // Mock data
    const mockScholarships = [
      { 
        id: 1, 
        title: 'Scholarship 1', 
        amount: 1000,
        company_name: 'Test Company'
      },
      { 
        id: 2, 
        title: 'Scholarship 2', 
        amount: 2000,
        company_name: 'Test Company 2'
      }
    ];
    
    // Mock the database response
    query.mockResolvedValue(mockScholarships);
    
    // Call the controller method
    await scholarshipController.getAllScholarships(req, res);
    
    // Verify the response
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({
      success: true,
      count: mockScholarships.length,
      data: mockScholarships
    });
  });
  
  test('getScholarshipById should return a single scholarship', async () => {
    // Mock data
    const mockScholarship = { 
      id: 1, 
      title: 'Scholarship 1', 
      amount: 1000,
      company_name: 'Test Company'
    };
    
    // Setup request parameters
    req.params.id = 1;
    
    // Mock the database response
    query.mockResolvedValue([mockScholarship]);
    
    // Call the controller method
    await scholarshipController.getScholarshipById(req, res);
    
    // Verify the response
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({
      success: true,
      data: mockScholarship
    });
  });
  
  test('createScholarship should create a new scholarship', async () => {
    // Setup mock company profile
    const mockCompanyProfile = { id: 1 };
    query.mockResolvedValueOnce([mockCompanyProfile]); // First query to get company profile
    
    // Mock database response for INSERT
    const mockInsertResult = [{ id: 1 }];
    query.mockResolvedValueOnce(mockInsertResult); // Second query to insert scholarship
    
    // Setup request body
    req.body = {
      title: 'New Scholarship',
      amount: 5000,
      description: 'Scholarship description',
      openDate: '2025-01-01',
      deadline: '2025-12-31',
      recipientsCount: 1,
      educationLevel: 'Undergraduate',
      minGpa: 3.0,
      fieldsOfStudy: ['Computer Science'],
      additionalRequirements: 'Must be active student',
      requiredDocuments: ['Transcript'],
      essayPrompt: 'Why do you deserve this scholarship?'
    };
    
    // Call the controller method
    await scholarshipController.createScholarship(req, res);
    
    // Verify the response
    // expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith({
      success: true,
      message: "Scholarship created successfully",
      data: { scholarshipId: 1 }
    });
  });
  
  test('updateScholarship should update an existing scholarship', async () => {
    // Setup mock company profile and scholarship
    const mockCompanyProfile = { id: 1 };
    query.mockResolvedValueOnce([mockCompanyProfile]); // First query to get company profile
    
    const mockScholarship = { id: 1, company_id: 1 };
    query.mockResolvedValueOnce([mockScholarship]); // Second query to find scholarship
    
    query.mockResolvedValueOnce([]); // Third query to update scholarship
    
    // Setup request params and body
    req.params.id = 1;
    req.body = {
      title: 'Updated Scholarship',
      amount: 6000,
      description: 'Updated description',
      openDate: '2025-01-01',
      deadline: '2025-12-31',
      recipientsCount: 2,
      status: 'active'
    };
    
    // Call the controller method
    await scholarshipController.updateScholarship(req, res);
    
    // Verify the response
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({
      success: true,
      message: "Scholarship updated successfully"
    });
  });
  
  test('deleteScholarship should delete a scholarship', async () => {
    // Setup mock company profile and scholarship
    const mockCompanyProfile = { id: 1 };
    query.mockResolvedValueOnce([mockCompanyProfile]); // First query to get company profile
    
    const mockScholarship = { id: 1, company_id: 1 };
    query.mockResolvedValueOnce([mockScholarship]); // Second query to find scholarship
    
    query.mockResolvedValueOnce([]); // Third query to delete scholarship
    
    // Setup request params
    req.params.id = 1;
    
    // Call the controller method
    await scholarshipController.deleteScholarship(req, res);
    
    // Verify the response
    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith({
      success: true,
      message: "Scholarship deleted successfully"
    });
  });
});