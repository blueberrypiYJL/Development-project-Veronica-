// backend/tests/unit/auth.test.js
const { hashPassword, comparePassword, generateToken } = require('../../utils/auth');
const jwt = require('jsonwebtoken');
const authController = require('../../controllers/authController');

// Set unit test mode
process.env.TEST_TYPE = 'unit';

// Mock database
jest.mock('../../config/db', () => require('../../config/test-db'));

describe('Auth Utils', () => {
  test('should hash password correctly', async () => {
    const password = 'test123';
    const hashedPassword = await hashPassword(password);
    
    // Hash should be different from original password
    expect(hashedPassword).not.toBe(password);
    
    // Should be able to compare and get true
    const isMatch = await comparePassword(password, hashedPassword);
    expect(isMatch).toBe(true);
  });

  test('should generate valid token', () => {
    const userId = '123';
    process.env.JWT_SECRET = 'testsecret';
    
    const token = generateToken(userId);
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    expect(decoded.id).toBe(userId);
  });

  test('comparePassword should return false for incorrect password', async () => {
    const password = 'correctPassword';
    const hashedPassword = await hashPassword(password);
    const isMatch = await comparePassword('wrongPassword', hashedPassword);
    expect(isMatch).toBe(false);
  });
});

describe('Auth Controller', () => {
  // Mock request and response objects
  let req, res;
  
  // beforeEach(() => {
  //   req = {
  //     body: {},
  //     user: {}
  //   };
  //   res = {
  //     status: jest.fn().mockReturnThis(),
  //     json: jest.fn()
  //   };
  // });
  
  // test('getCurrentUser should return user data', async () => {
  //   // Setup mock user in request
  //   req.user = {
  //     id: 1,
  //     email: 'test@example.com',
  //     name: 'Test User',
  //     user_type: 'student'
  //   };
    
  //   await authController.getCurrentUser(req, res);
    
  //   expect(res.status).toHaveBeenCalledWith(200);
  //   expect(res.json).toHaveBeenCalledWith({
  //     success: true,
  //     data: {
  //       id: 1,
  //       email: 'test@example.com',
  //       name: 'Test User',
  //       userType: 'student'
  //     }
  //   });
  // });
  
  // Add more unit tests for register and login with mocked query responses
});