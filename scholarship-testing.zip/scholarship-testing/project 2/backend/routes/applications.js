const express = require("express");
const { body } = require("express-validator");
const applicationController = require("../controllers/applicationController");
const { protect, restrictTo } = require("../middleware/auth");

const router = express.Router();

// Student routes
router.get(
  "/",
  protect,
  // restrictTo("student"),
  applicationController.getStudentApplications
);

router.post(
  "/start",
  protect,
  // restrictTo("student"),
  [body("scholarshipId").notEmpty().withMessage("Scholarship ID is required")],
  applicationController.startApplication
);

router.post(
  "/",
  protect,
  // restrictTo("student"),
  [
    body("scholarshipId").notEmpty().withMessage("Scholarship ID is required"),
    body("essayResponse").notEmpty().withMessage("Essay response is required"),
  ],
  applicationController.submitApplication
);

// Company routes
router.get(
  "/company",
  protect,
  // restrictTo("company"),
  applicationController.getCompanyApplications
);

router.put(
  "/:id/status",
  protect,
  // restrictTo("company"),
  [
    body("status")
      .isIn(["under_review", "accepted", "rejected"])
      .withMessage("Status must be under_review, accepted, or rejected"),
  ],
  applicationController.updateApplicationStatus
);

// Shared routes
router.get("/:id", protect, applicationController.getApplicationById);

module.exports = router;
