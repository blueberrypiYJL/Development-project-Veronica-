const express = require("express");
const { body } = require("express-validator");
const profileController = require("../controllers/profileController");
const { protect, restrictTo } = require("../middleware/auth");

const router = express.Router();

// Student profile routes
router.get(
  "/student",
  // protect,
  // restrictTo("student"),
  profileController.getStudentProfile
);

router.put(
  "/student",
  // protect,
  // restrictTo("student"),
  [
    body("firstName").notEmpty().withMessage("First name is required"),
    body("lastName").notEmpty().withMessage("Last name is required"),
  ],
  profileController.updateStudentProfile
);

// Company profile routes
router.get(
  "/company",
  // protect,
  // restrictTo("company"),
  profileController.getCompanyProfile
);

router.put(
  "/company",
  // protect,
  // restrictTo("company"),
  [
    body("companyName").notEmpty().withMessage("Company name is required"),
    body("contactName").notEmpty().withMessage("Contact name is required"),
    body("industry").notEmpty().withMessage("Industry is required"),
  ],
  profileController.updateCompanyProfile
);

module.exports = router;
