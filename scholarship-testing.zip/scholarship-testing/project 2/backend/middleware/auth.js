// backend/middleware/auth.js
const jwt = require('jsonwebtoken');

/**
 * Authentication middleware to protect routes
 */
const protect = async (req, res, next) => {
  let token;

  try {
    // Check if authorization header exists and has Bearer token
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      // Get token from header (format: "Bearer xxxx")
      token = req.headers.authorization.split(' ')[1];

      // If no token provided
      if (!token) {
        return res.status(401).json({
          success: false,
          message: "Not authorized, no token provided"
        });
      }

      try {
        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'test-jwt-secret');

        // Add user info to request
        req.user = {
          id: decoded.id,
          user_type: decoded.user_type || null // Add user type if available
        };

        next();
      } catch (error) {
        // If token verification fails
        console.error("Token verification error:", error);
        return res.status(401).json({
          success: false,
          message: "Not authorized, invalid token"
        });
      }
    } else {
      // No Bearer token in header
      return res.status(401).json({
        success: false,
        message: "Not authorized, no token provided"
      });
    }
  } catch (error) {
    console.error("Auth middleware error:", error);
    return res.status(401).json({
      success: false,
      message: "Not authorized, token failed",
    });
  }
};

/**
 * Role-based authorization middleware
 * @param {Array} roles - Array of allowed roles
 */
const authorize = (roles) => {
  return (req, res, next) => {
    // Check if user exists and has a user_type
    if (!req.user || !req.user.user_type) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: User role not found"
      });
    }

    // Check if user role is in the allowed roles
    if (!roles.includes(req.user.user_type)) {
      return res.status(403).json({
        success: false,
        message: `Forbidden: User role ${req.user.user_type} not authorized to access this resource`
      });
    }

    next();
  };
};

module.exports = { protect, authorize };