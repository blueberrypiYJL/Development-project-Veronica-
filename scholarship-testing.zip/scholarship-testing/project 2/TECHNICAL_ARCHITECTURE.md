# Scholarship Finder - Technical Architecture

## Overview

The Scholarship Finder application is built using a modern microservices architecture, separating the frontend and backend into distinct applications. This document focuses on the backend architecture.

## Technology Stack

- **Runtime Environment**: Node.js
- **Framework**: Express.js
- **Database**: PostgreSQL via Neon DB
- **Authentication**: JWT (JSON Web Tokens)
- **API Style**: RESTful
- **Testing**: Jest and Supertest
- **Code Quality**: ESLint
- **Security**: Helmet, Express Rate Limit, CORS
- **Validation**: Express Validator

## Architecture Layers

The backend follows a clean architecture approach with the following layers:

### 1. Routes Layer

- Defines API endpoints
- Handles request validation
- Routes requests to appropriate controllers

### 2. Controller Layer

- Processes HTTP requests
- Coordinates business logic
- Returns HTTP responses
- Handles error cases

### 3. Service Layer

- Contains business logic
- Interacts with the data access layer
- Enforces business rules

### 4. Data Access Layer

- Abstracts database operations
- Uses PostgreSQL via Neon DB
- Provides a clean interface for database queries

## Directory Structure

```
backend/
├── config/           # Configuration files
│   └── db.js         # Database connection
├── controllers/      # Request handlers
│   ├── authController.js
│   ├── scholarshipController.js
│   ├── applicationController.js
│   └── profileController.js
├── middleware/       # Express middleware
│   └── auth.js       # Authentication middleware
├── models/           # Data models (future enhancement)
├── routes/           # API routes
│   ├── auth.js
│   ├── scholarships.js
│   ├── applications.js
│   └── profiles.js
├── services/         # Business logic (future enhancement)
│   ├── authService.js
│   ├── scholarshipService.js
│   └── applicationService.js
├── utils/            # Utility functions
│   └── auth.js       # Authentication utilities
├── server.js         # Main entry point
└── package.json      # Dependencies
```

## Database Schema

The application uses a relational database model with the following key tables:

1. **users**: Core user accounts for both students and companies
2. **student_profiles**: Student profile information
3. **student_education**: Student education details
4. **student_achievements**: Student achievements and skills
5. **company_profiles**: Company profile information
6. **scholarships**: Scholarship listings
7. **applications**: Student applications for scholarships

See `schema.sql` in the project root for the complete schema.

## Authentication Flow

1. **Registration**: User registers with email/password

   - Password is hashed using bcrypt
   - User record is created in the database
   - JWT token is generated and returned

2. **Login**: User logs in with email/password

   - System validates credentials
   - JWT token is generated and returned

3. **Protected Routes**: Access to protected routes
   - JWT token is validated via middleware
   - User information is attached to the request
   - Role-based access control is enforced

## API Structure

The API follows RESTful principles and is versioned with a `/api/v1` prefix. Major resource endpoints include:

- `/api/v1/auth`: Authentication operations
- `/api/v1/scholarships`: Scholarship management
- `/api/v1/applications`: Application handling
- `/api/v1/profiles`: User profile management

## Error Handling

Errors are handled centrally using Express middleware, providing consistent error responses:

- **Validation errors**: 400 Bad Request with specific field errors
- **Authentication errors**: 401 Unauthorized
- **Authorization errors**: 403 Forbidden
- **Not found errors**: 404 Not Found
- **Server errors**: 500 Internal Server Error

## Security Measures

The application implements several security best practices:

1. **HTTPS**: All communications should be over HTTPS
2. **Password Security**: Passwords hashed with bcrypt
3. **JWT Security**: Short-lived tokens with proper signing
4. **Input Validation**: All inputs validated with express-validator
5. **SQL Injection Prevention**: Parameterized queries
6. **API Rate Limiting**: Prevents abuse
7. **Security Headers**: Using Helmet middleware
8. **CORS**: Restricting cross-origin requests

## Scalability Considerations

- **Horizontal Scaling**: Stateless design allows for easy scaling
- **Connection Pooling**: Efficient database connections
- **Caching**: Can be implemented for frequently accessed data
- **Pagination**: Implemented for list endpoints

## Future Enhancements

1. **Service Layer**: Extract business logic from controllers into dedicated service classes
2. **OAuth Integration**: Support for social login
3. **Refresh Tokens**: Implement refresh token mechanism
4. **File Upload**: Add support for document uploads using cloud storage
5. **WebSockets**: Real-time notifications for application updates
6. **Queues**: Background processing for heavy tasks
