import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import axios from "axios";
import { useAuth } from "@/contexts/AuthContext";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api/v1";

type Application = {
  id: number;
  scholarship_id: number;
  status: string;
  title: string;
  company_name: string;
  amount: number;
  deadline: string;
  submitted_at: string;
  feedback?: string;
};

const StudentDashboardPage = () => {
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        // Set up auth header
        const token = localStorage.getItem("token");
        const config = {
          headers: { Authorization: `Bearer ${token}` },
        };

        const response = await axios.get(`${API_URL}/applications`, config);
        if (response.data.success) {
          setApplications(response.data.data);
        } else {
          toast.error("Failed to fetch applications");
        }
      } catch (error: unknown) {
        console.error("Error fetching applications:", error);
        toast.error("An error occurred while fetching applications");
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
  }, []);

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "submitted":
        return "bg-blue-100 text-blue-800";
      case "under_review":
        return "bg-yellow-100 text-yellow-800";
      case "accepted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatStatus = (status: string) => {
    switch (status) {
      case "submitted":
        return "Submitted";
      case "under_review":
        return "Under Review";
      case "accepted":
        return "Accepted";
      case "rejected":
        return "Rejected";
      case "started":
        return "Draft";
      default:
        return status;
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Student Dashboard</h1>
        <Button asChild>
          <Link to="/scholarships">Find More Scholarships</Link>
        </Button>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Your Profile</CardTitle>
          <CardDescription>Manage your student information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="text-muted-foreground mb-1">Name</div>
            <div className="font-medium">{user?.name || "Not set"}</div>
          </div>
          <div className="mb-4">
            <div className="text-muted-foreground mb-1">Email</div>
            <div className="font-medium">{user?.email || "Not set"}</div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline">
            <Link to="/profile">Edit Profile</Link>
          </Button>
        </CardFooter>
      </Card>

      <h2 className="text-2xl font-bold mb-4">Your Applications</h2>

      {loading ? (
        <div className="flex justify-center py-8">Loading applications...</div>
      ) : applications.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              You haven't applied to any scholarships yet.
            </p>
            <Button asChild>
              <Link to="/scholarships">Browse Scholarships</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {applications.map((application) => (
            <Card key={application.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{application.title}</CardTitle>
                    <CardDescription>
                      {application.company_name}
                    </CardDescription>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeClass(
                      application.status
                    )}`}
                  >
                    {formatStatus(application.status)}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <div className="text-muted-foreground text-sm">Amount</div>
                    <div className="font-medium">
                      {formatAmount(application.amount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-sm">
                      Deadline
                    </div>
                    <div className="font-medium">
                      {formatDate(application.deadline)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-sm">
                      Submitted On
                    </div>
                    <div className="font-medium">
                      {application.submitted_at
                        ? formatDate(application.submitted_at)
                        : "Not submitted"}
                    </div>
                  </div>
                </div>
                {application.status === "rejected" && application.feedback && (
                  <div className="mt-4 p-3 bg-red-50 rounded-md">
                    <div className="text-sm font-medium text-red-800 mb-1">
                      Feedback:
                    </div>
                    <div className="text-sm text-red-700">
                      {application.feedback}
                    </div>
                  </div>
                )}
                {application.status === "accepted" && application.feedback && (
                  <div className="mt-4 p-3 bg-green-50 rounded-md">
                    <div className="text-sm font-medium text-green-800 mb-1">
                      Message:
                    </div>
                    <div className="text-sm text-green-700">
                      {application.feedback}
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full sm:w-auto">
                  <Link to={`/scholarships/${application.scholarship_id}`}>
                    View Scholarship
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentDashboardPage;
