import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";

const HomePage = () => {
  const { user } = useAuth();

  return (
    <div className="flex flex-col gap-8">
      {/* Hero Section */}
      <section className="flex flex-col gap-4 text-center py-12">
        <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl">
          Find the Perfect Scholarship for Your Education
        </h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Connect with opportunities from leading companies and organizations to
          fund your academic journey
        </p>
        <div className="flex gap-4 justify-center mt-6">
          {!user && (
            <>
              <Button asChild size="lg">
                <Link to="/register">Get Started</Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/scholarships">Browse Scholarships</Link>
              </Button>
            </>
          )}
          {user?.userType === "student" && (
            <Button asChild size="lg">
              <Link to="/scholarships">Find Scholarships</Link>
            </Button>
          )}
          {user?.userType === "company" && (
            <Button asChild size="lg">
              <Link to="/company/dashboard">Manage Scholarships</Link>
            </Button>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold">How It Works</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>For Students</CardTitle>
              <CardDescription>
                Find scholarships that match your profile
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>Create a comprehensive profile</li>
                <li>Browse available scholarships</li>
                <li>Track your applications</li>
                <li>Receive updates on your status</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>For Companies</CardTitle>
              <CardDescription>
                Create and manage scholarship programs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>Create custom scholarship listings</li>
                <li>Review and manage applications</li>
                <li>Connect with promising students</li>
                <li>Track your impact</li>
              </ul>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Security & Support</CardTitle>
              <CardDescription>
                We prioritize your data and experience
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>Secure account management</li>
                <li>Data privacy protection</li>
                <li>Responsive support team</li>
                <li>Regular platform updates</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
