import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api/v1";

type Scholarship = {
  id: number;
  title: string;
  amount: number;
  deadline: string;
  company_name: string;
  description: string;
  education_level?: string;
  min_gpa?: number;
  fields_of_study?: string;
  recipients_count?: number;
  additional_requirements?: string;
  essay_prompt?: string;
};

const ScholarshipDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const [scholarship, setScholarship] = useState<Scholarship | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const fetchScholarship = async () => {
      try {
        const response = await axios.get(`${API_URL}/scholarships/${id}`);
        if (response.data.success) {
          setScholarship(response.data.data);
        } else {
          toast.error("Failed to fetch scholarship details");
        }
      } catch (error: unknown) {
        console.error("Error fetching scholarship details:", error);
        toast.error("An error occurred while fetching scholarship details");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchScholarship();
    }
  }, [id]);

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const handleApply = async () => {
    toast.info("Application functionality will be implemented soon");
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        Loading scholarship details...
      </div>
    );
  }

  if (!scholarship) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Scholarship Not Found</h2>
        <p className="text-muted-foreground mb-6">
          The scholarship you're looking for doesn't exist or has been removed.
        </p>
        <Button asChild>
          <Link to="/scholarships">Back to Scholarships</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <Link to="/scholarships" className="text-primary hover:underline">
          &larr; Back to Scholarships
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-3xl">{scholarship.title}</CardTitle>
          <CardDescription className="text-lg">
            Offered by {scholarship.company_name}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="text-muted-foreground">Amount</div>
              <div className="text-2xl font-bold">
                {formatAmount(scholarship.amount)}
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-muted-foreground">Deadline</div>
              <div className="text-2xl font-bold">
                {formatDate(scholarship.deadline)}
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-muted-foreground">Education Level</div>
              <div className="font-medium">
                {scholarship.education_level || "Any"}
              </div>
            </div>
            <div className="space-y-2">
              <div className="text-muted-foreground">Fields of Study</div>
              <div className="font-medium">
                {scholarship.fields_of_study || "Any"}
              </div>
            </div>
            {scholarship.min_gpa && (
              <div className="space-y-2">
                <div className="text-muted-foreground">Minimum GPA</div>
                <div className="font-medium">{scholarship.min_gpa}</div>
              </div>
            )}
            <div className="space-y-2">
              <div className="text-muted-foreground">Recipients</div>
              <div className="font-medium">{scholarship.recipients_count}</div>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-xl font-semibold">Description</h3>
            <p className="whitespace-pre-wrap">{scholarship.description}</p>
          </div>

          {scholarship.additional_requirements && (
            <div className="space-y-2">
              <h3 className="text-xl font-semibold">Additional Requirements</h3>
              <p className="whitespace-pre-wrap">
                {scholarship.additional_requirements}
              </p>
            </div>
          )}

          {scholarship.essay_prompt && (
            <div className="space-y-2">
              <h3 className="text-xl font-semibold">Essay Prompt</h3>
              <p className="whitespace-pre-wrap">{scholarship.essay_prompt}</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          {user?.userType === "student" ? (
            <Button onClick={handleApply} className="w-full">
              Apply Now
            </Button>
          ) : user?.userType === "company" ? (
            <div className="w-full text-center text-muted-foreground">
              You are logged in as a company account. Switch to a student
              account to apply.
            </div>
          ) : (
            <Button asChild className="w-full">
              <Link to="/login">Login to Apply</Link>
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default ScholarshipDetailPage;
