import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api/v1";

type Scholarship = {
  id: number;
  title: string;
  amount: number;
  deadline: string;
  company_name: string;
  description: string;
  education_level?: string;
  min_gpa?: number;
  fields_of_study?: string;
};

const ScholarshipsPage = () => {
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [educationFilter, setEducationFilter] = useState("");

  useEffect(() => {
    const fetchScholarships = async () => {
      try {
        const response = await axios.get(`${API_URL}/scholarships`);
        if (response.data.success) {
          setScholarships(response.data.data);
        } else {
          toast.error("Failed to fetch scholarships");
        }
      } catch (error: unknown) {
        console.error("Error fetching scholarships:", error);
        toast.error("An error occurred while fetching scholarships");
      } finally {
        setLoading(false);
      }
    };

    fetchScholarships();
  }, []);

  // Filter scholarships based on search term and education level
  const filteredScholarships = scholarships.filter((scholarship) => {
    const matchesSearch =
      searchTerm === "" ||
      scholarship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scholarship.description
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      scholarship.company_name
        .toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      (scholarship.fields_of_study &&
        scholarship.fields_of_study
          .toLowerCase()
          .includes(searchTerm.toLowerCase()));

    const matchesEducation =
      educationFilter === "" ||
      (scholarship.education_level &&
        scholarship.education_level.toLowerCase() ===
          educationFilter.toLowerCase());

    return matchesSearch && matchesEducation;
  });

  // Format currency
  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-4">Available Scholarships</h1>
        <div className="grid gap-4 md:grid-cols-[3fr_1fr]">
          <Input
            placeholder="Search scholarships..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-3xl"
          />
          <select
            value={educationFilter}
            onChange={(e) => setEducationFilter(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <option value="">All education levels</option>
            <option value="undergraduate">Undergraduate</option>
            <option value="graduate">Graduate</option>
            <option value="phd">PhD</option>
            <option value="any">Any</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">Loading scholarships...</div>
      ) : filteredScholarships.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground mb-4">
            No scholarships found matching your criteria.
          </p>
          <Button
            onClick={() => {
              setSearchTerm("");
              setEducationFilter("");
            }}
          >
            Clear filters
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredScholarships.map((scholarship) => (
            <Card key={scholarship.id} className="flex flex-col">
              <CardHeader>
                <CardTitle>{scholarship.title}</CardTitle>
                <CardDescription>{scholarship.company_name}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Amount:</span>
                    <span className="font-medium">
                      {formatAmount(scholarship.amount)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Deadline:</span>
                    <span className="font-medium">
                      {formatDate(scholarship.deadline)}
                    </span>
                  </div>
                  {scholarship.education_level && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Education:</span>
                      <span className="font-medium">
                        {scholarship.education_level}
                      </span>
                    </div>
                  )}
                  <p className="text-sm mt-4 line-clamp-3">
                    {scholarship.description}
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link to={`/scholarships/${scholarship.id}`}>
                    View Details
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default ScholarshipsPage;
