import { Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import Navbar from "@/components/Navbar";
import HomePage from "@/pages/HomePage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";
import ScholarshipsPage from "@/pages/ScholarshipsPage";
import ScholarshipDetailPage from "@/pages/ScholarshipDetailPage";
import StudentDashboardPage from "@/pages/StudentDashboardPage";
import CompanyDashboardPage from "@/pages/CompanyDashboardPage";
import ProfilePage from "@/pages/ProfilePage";
import { AuthProvider } from "@/contexts/AuthContext";

function App() {
  return (
    <AuthProvider>
      
        <div className="min-h-screen bg-background">
          <Navbar />
          <main className="container mx-auto py-8 px-4">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/scholarships" element={<ScholarshipsPage />} />
              <Route
                path="/scholarships/:id"
                element={<ScholarshipDetailPage />}
              />
              <Route
                path="/student/dashboard"
                element={<StudentDashboardPage />}
              />
              <Route
                path="/company/dashboard"
                element={<CompanyDashboardPage />}
              />
              <Route path="/profile" element={<ProfilePage />} />
            </Routes>
          </main>
          <Toaster />
        </div>
      
    </AuthProvider>
  );
}

export default App;
