const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Get all scholarships
// @route   GET /api/v1/scholarships
// @access  Public
exports.getAllScholarships = async (req, res) => {
  try {
    // Get active scholarships with company information
    const scholarships = await query(
      `SELECT s.*, cp.company_name 
       FROM scholarships s
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE s.status = 'active' AND s.deadline >= CURRENT_DATE
       ORDER BY s.deadline ASC`
    );

    res.status(200).json({
      success: true,
      count: scholarships.length,
      data: scholarships,
    });
  } catch (error) {
    console.error("Get all scholarships error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get scholarship by ID
// @route   GET /api/v1/scholarships/:id
// @access  Public
exports.getScholarshipById = async (req, res) => {
  try {
    const scholarships = await query(
      `SELECT s.*, cp.company_name 
       FROM scholarships s
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE s.id = $1`,
      [req.params.id]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    res.status(200).json({
      success: true,
      data: scholarships[0],
    });
  } catch (error) {
    console.error("Get scholarship by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create scholarship
// @route   POST /api/v1/scholarships
// @access  Private/Company
exports.createScholarship = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Extract data from request body
    const {
      title,
      amount,
      description,
      openDate,
      deadline,
      recipientsCount,
      educationLevel,
      minGpa,
      fieldsOfStudy,
      additionalRequirements,
      requiredDocuments,
      essayPrompt,
      status,
    } = req.body;

    // Insert scholarship
    const result = await query(
      `INSERT INTO scholarships (
        company_id, title, amount, description, open_date, deadline, 
        recipients_count, education_level, min_gpa, fields_of_study, 
        additional_requirements, required_documents, essay_prompt, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING id`,
      [
        companyId,
        title,
        amount,
        description,
        openDate,
        deadline,
        recipientsCount,
        educationLevel,
        minGpa,
        fieldsOfStudy,
        additionalRequirements,
        requiredDocuments,
        essayPrompt,
        status || "draft",
      ]
    );

    const scholarshipId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Scholarship created successfully",
      data: { scholarshipId },
    });
  } catch (error) {
    console.error("Create scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Update scholarship
// @route   PUT /api/v1/scholarships/:id
// @access  Private/Company
exports.updateScholarship = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Check if scholarship exists and belongs to company
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1 AND company_id = $2",
      [req.params.id, companyId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found or not authorized",
      });
    }

    // Extract data from request body
    const {
      title,
      amount,
      description,
      openDate,
      deadline,
      recipientsCount,
      educationLevel,
      minGpa,
      fieldsOfStudy,
      additionalRequirements,
      requiredDocuments,
      essayPrompt,
      status,
    } = req.body;

    // Update scholarship
    await query(
      `UPDATE scholarships SET
        title = $1,
        amount = $2,
        description = $3,
        open_date = $4,
        deadline = $5,
        recipients_count = $6,
        education_level = $7,
        min_gpa = $8,
        fields_of_study = $9,
        additional_requirements = $10,
        required_documents = $11,
        essay_prompt = $12,
        status = $13,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $14 AND company_id = $15`,
      [
        title,
        amount,
        description,
        openDate,
        deadline,
        recipientsCount,
        educationLevel,
        minGpa,
        fieldsOfStudy,
        additionalRequirements,
        requiredDocuments,
        essayPrompt,
        status,
        req.params.id,
        companyId,
      ]
    );

    res.status(200).json({
      success: true,
      message: "Scholarship updated successfully",
    });
  } catch (error) {
    console.error("Update scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Delete scholarship
// @route   DELETE /api/v1/scholarships/:id
// @access  Private/Company
exports.deleteScholarship = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Check if scholarship exists and belongs to company
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1 AND company_id = $2",
      [req.params.id, companyId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found or not authorized",
      });
    }

    // Delete scholarship
    await query("DELETE FROM scholarships WHERE id = $1", [req.params.id]);

    res.status(200).json({
      success: true,
      message: "Scholarship deleted successfully",
    });
  } catch (error) {
    console.error("Delete scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company scholarships
// @route   GET /api/v1/scholarships/company
// @access  Private/Company
exports.getCompanyScholarships = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Get scholarships
    const scholarships = await query(
      `SELECT * FROM scholarships 
       WHERE company_id = $1 
       ORDER BY created_at DESC`,
      [companyId]
    );

    res.status(200).json({
      success: true,
      count: scholarships.length,
      data: scholarships,
    });
  } catch (error) {
    console.error("Get company scholarships error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};


scholarship-controller;

const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Submit application
// @route   POST /api/v1/applications
// @access  Private/Student
exports.submitApplication = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;
    const { scholarshipId, essayResponse, documentsUrls } = req.body;

    // Check if scholarship exists
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1",
      [scholarshipId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    // Check if already applied
    const existingApplications = await query(
      "SELECT * FROM applications WHERE scholarship_id = $1 AND student_id = $2",
      [scholarshipId, studentId]
    );

    if (existingApplications.length > 0) {
      // If already started, update it
      const existingApp = existingApplications[0];

      await query(
        `UPDATE applications 
        SET essay_response = $1, documents_urls = $2, status = 'submitted', submitted_at = CURRENT_TIMESTAMP 
        WHERE id = $3`,
        [essayResponse, documentsUrls, existingApp.id]
      );

      return res.status(200).json({
        success: true,
        message: "Application submitted successfully",
        data: { applicationId: existingApp.id },
      });
    }

    // Create new application
    const result = await query(
      `INSERT INTO applications 
      (scholarship_id, student_id, essay_response, documents_urls, status, submitted_at) 
      VALUES ($1, $2, $3, $4, 'submitted', CURRENT_TIMESTAMP) RETURNING id`,
      [scholarshipId, studentId, essayResponse, documentsUrls]
    );

    const applicationId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Application submitted successfully",
      data: { applicationId },
    });
  } catch (error) {
    console.error("Submit application error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Start application
// @route   POST /api/v1/applications/start
// @access  Private/Student
exports.startApplication = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;
    const { scholarshipId } = req.body;

    // Check if scholarship exists
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1",
      [scholarshipId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    // Check if already applied
    const existingApplications = await query(
      "SELECT * FROM applications WHERE scholarship_id = $1 AND student_id = $2",
      [scholarshipId, studentId]
    );

    if (existingApplications.length > 0) {
      return res.status(400).json({
        success: false,
        message: "You have already started an application for this scholarship",
        data: { applicationId: existingApplications[0].id },
      });
    }

    // Create new application
    const result = await query(
      "INSERT INTO applications (scholarship_id, student_id, status) VALUES ($1, $2, $3) RETURNING id",
      [scholarshipId, studentId, "started"]
    );

    const applicationId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Application started successfully",
      data: { applicationId },
    });
  } catch (error) {
    console.error("Start application error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get student applications
// @route   GET /api/v1/applications
// @access  Private/Student
exports.getStudentApplications = async (req, res) => {
  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;

    // Get applications with scholarship and company details
    const applications = await query(
      `SELECT a.*, s.title, s.amount, s.deadline, cp.company_name
       FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE a.student_id = $1
       ORDER BY a.created_at DESC`,
      [studentId]
    );

    res.status(200).json({
      success: true,
      count: applications.length,
      data: applications,
    });
  } catch (error) {
    console.error("Get student applications error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company applications
// @route   GET /api/v1/applications/company
// @access  Private/Company
exports.getCompanyApplications = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Get applications for company scholarships
    const applications = await query(
      `SELECT a.*, s.title as scholarship_title, 
              sp.first_name, sp.last_name,
              u.email as student_email
       FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       JOIN student_profiles sp ON a.student_id = sp.id
       JOIN users u ON sp.user_id = u.id
       WHERE s.company_id = $1
       ORDER BY a.submitted_at DESC`,
      [companyId]
    );

    res.status(200).json({
      success: true,
      count: applications.length,
      data: applications,
    });
  } catch (error) {
    console.error("Get company applications error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get application by ID
// @route   GET /api/v1/applications/:id
// @access  Private
exports.getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;
    let application;

    if (req.user.user_type === "student") {
      // Get student profile
      const studentProfiles = await query(
        "SELECT * FROM student_profiles WHERE user_id = $1",
        [req.user.id]
      );

      if (studentProfiles.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Student profile not found",
        });
      }

      const studentId = studentProfiles[0].id;

      // Get application if it belongs to student
      const applications = await query(
        `SELECT a.*, s.title, s.amount, s.deadline, s.essay_prompt, cp.company_name
         FROM applications a
         JOIN scholarships s ON a.scholarship_id = s.id
         JOIN company_profiles cp ON s.company_id = cp.id
         WHERE a.id = $1 AND a.student_id = $2`,
        [id, studentId]
      );

      if (applications.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Application not found or unauthorized",
        });
      }

      application = applications[0];
    } else if (req.user.user_type === "company") {
      // Get company profile
      const companyProfiles = await query(
        "SELECT * FROM company_profiles WHERE user_id = $1",
        [req.user.id]
      );

      if (companyProfiles.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Company profile not found",
        });
      }

      const companyId = companyProfiles[0].id;

      // Get application if it belongs to company's scholarship
      const applications = await query(
        `SELECT a.*, s.title as scholarship_title, s.essay_prompt,
                sp.first_name, sp.last_name,
                u.email as student_email
         FROM applications a
         JOIN scholarships s ON a.scholarship_id = s.id
         JOIN student_profiles sp ON a.student_id = sp.id
         JOIN users u ON sp.user_id = u.id
         WHERE a.id = $1 AND s.company_id = $2`,
        [id, companyId]
      );

      if (applications.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Application not found or unauthorized",
        });
      }

      application = applications[0];
    } else {
      return res.status(403).json({
        success: false,
        message: "Unauthorized user type",
      });
    }

    res.status(200).json({
      success: true,
      data: application,
    });
  } catch (error) {
    console.error("Get application by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Update application status (for companies)
// @route   PUT /api/v1/applications/:id/status
// @access  Private/Company
exports.updateApplicationStatus = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const { id } = req.params;
    const { status, feedback } = req.body;

    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Verify application belongs to company's scholarship
    const applications = await query(
      `SELECT a.* FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       WHERE a.id = $1 AND s.company_id = $2`,
      [id, companyId]
    );

    if (applications.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Application not found or unauthorized",
      });
    }

    // Update application status
    await query(
      "UPDATE applications SET status = $1, feedback = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
      [status, feedback, id]
    );

    res.status(200).json({
      success: true,
      message: "Application status updated successfully",
    });
  } catch (error) {
    console.error("Update application status error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};


application-controller.js


const { query } = require("../config/db");
const {
  generateToken,
  hashPassword,
  comparePassword,
} = require("../utils/auth");
const { validationResult } = require("express-validator");

// @desc    Register a new user
// @route   POST /api/v1/auth/register
// @access  Public
exports.register = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  const { email, password, name, userType } = req.body;

  try {
    // Check if user exists
    const existingUsers = await query("SELECT * FROM users WHERE email = $1", [
      email,
    ]);

    if (existingUsers.length > 0) {
      return res.status(400).json({
        success: false,
        message: "User already exists",
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Insert user
    const result = await query(
      "INSERT INTO users (email, password_hash, name, user_type) VALUES ($1, $2, $3, $4) RETURNING id, email, name, user_type",
      [email, hashedPassword, name, userType]
    );

    const newUser = result[0];

    // Generate token
    const token = generateToken(newUser.id);

    res.status(201).json({
      success: true,
      data: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        userType: newUser.user_type,
        token,
      },
    });
  } catch (error) {
    console.error("Register error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during registration",
    });
  }
};

// @desc    Login user
// @route   POST /api/v1/auth/login
// @access  Public
exports.login = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  const { email, password } = req.body;

  try {
    // Check if user exists
    const users = await query("SELECT * FROM users WHERE email = $1", [email]);

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    const user = users[0];

    // Check password
    const isMatch = await comparePassword(password, user.password_hash);

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid credentials",
      });
    }

    // Generate token
    const token = generateToken(user.id);

    res.status(200).json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        name: user.name,
        userType: user.user_type,
        token,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({
      success: false,
      message: "Server error during login",
    });
  }
};

// @desc    Get current user
// @route   GET /api/v1/auth/current-user
// @access  Private
exports.getCurrentUser = async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      data: {
        id: req.user.id,
        email: req.user.email,
        name: req.user.name,
        userType: req.user.user_type,
      },
    });
  } catch (error) {
    console.error("Get current user error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};


auth-controller.js

const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Get student profile
// @route   GET /api/v1/profiles/student
// @access  Private/Student
exports.getStudentProfile = async (req, res) => {
  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    // If no profile exists, return empty profile
    if (studentProfiles.length === 0) {
      return res.status(200).json({
        success: true,
        data: null,
      });
    }

    const studentId = studentProfiles[0].id;

    // Get education details
    const educationDetails = await query(
      "SELECT * FROM student_education WHERE student_id = $1",
      [studentId]
    );

    // Get achievements
    const achievements = await query(
      "SELECT * FROM student_achievements WHERE student_id = $1",
      [studentId]
    );

    res.status(200).json({
      success: true,
      data: {
        profile: studentProfiles[0],
        education: educationDetails.length > 0 ? educationDetails[0] : null,
        achievements: achievements.length > 0 ? achievements[0] : null,
      },
    });
  } catch (error) {
    console.error("Get student profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create/Update student profile
// @route   PUT /api/v1/profiles/student
// @access  Private/Student
exports.updateStudentProfile = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const {
      firstName,
      lastName,
      phone,
      dob,
      gender,
      address,
      education,
      achievements,
    } = req.body;

    // Check if profile exists
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    let studentId;

    if (studentProfiles.length === 0) {
      // Create profile
      const result = await query(
        `INSERT INTO student_profiles 
         (user_id, first_name, last_name, phone, dob, gender, address) 
         VALUES ($1, $2, $3, $4, $5, $6, $7) 
         RETURNING id`,
        [req.user.id, firstName, lastName, phone, dob, gender, address]
      );
      studentId = result[0].id;
    } else {
      // Update profile
      studentId = studentProfiles[0].id;
      await query(
        `UPDATE student_profiles 
         SET first_name = $1, last_name = $2, phone = $3, dob = $4, 
             gender = $5, address = $6, updated_at = CURRENT_TIMESTAMP 
         WHERE id = $7`,
        [firstName, lastName, phone, dob, gender, address, studentId]
      );
    }

    // Handle education details
    if (education) {
      const educationDetails = await query(
        "SELECT * FROM student_education WHERE student_id = $1",
        [studentId]
      );

      if (educationDetails.length === 0) {
        // Create education record
        await query(
          `INSERT INTO student_education 
           (student_id, current_school, degree, major, gpa, graduation_date, previous_education) 
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [
            studentId,
            education.currentSchool,
            education.degree,
            education.major,
            education.gpa,
            education.graduationDate,
            education.previousEducation,
          ]
        );
      } else {
        // Update education record
        await query(
          `UPDATE student_education 
           SET current_school = $1, degree = $2, major = $3, 
               gpa = $4, graduation_date = $5, previous_education = $6, 
               updated_at = CURRENT_TIMESTAMP 
           WHERE student_id = $7`,
          [
            education.currentSchool,
            education.degree,
            education.major,
            education.gpa,
            education.graduationDate,
            education.previousEducation,
            studentId,
          ]
        );
      }
    }

    // Handle achievements
    if (achievements) {
      const achievementRecords = await query(
        "SELECT * FROM student_achievements WHERE student_id = $1",
        [studentId]
      );

      if (achievementRecords.length === 0) {
        // Create achievements record
        await query(
          `INSERT INTO student_achievements 
           (student_id, awards, activities, work_experience, skills) 
           VALUES ($1, $2, $3, $4, $5)`,
          [
            studentId,
            achievements.awards,
            achievements.activities,
            achievements.workExperience,
            achievements.skills,
          ]
        );
      } else {
        // Update achievements record
        await query(
          `UPDATE student_achievements 
           SET awards = $1, activities = $2, work_experience = $3, 
               skills = $4, updated_at = CURRENT_TIMESTAMP 
           WHERE student_id = $5`,
          [
            achievements.awards,
            achievements.activities,
            achievements.workExperience,
            achievements.skills,
            studentId,
          ]
        );
      }
    }

    res.status(200).json({
      success: true,
      message: "Student profile updated successfully",
    });
  } catch (error) {
    console.error("Update student profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company profile
// @route   GET /api/v1/profiles/company
// @access  Private/Company
exports.getCompanyProfile = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    // If no profile exists, return empty profile
    if (companyProfiles.length === 0) {
      return res.status(200).json({
        success: true,
        data: null,
      });
    }

    res.status(200).json({
      success: true,
      data: companyProfiles[0],
    });
  } catch (error) {
    console.error("Get company profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create/Update company profile
// @route   PUT /api/v1/profiles/company
// @access  Private/Company
exports.updateCompanyProfile = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const { companyName, website, contactName, industry, description } =
      req.body;

    // Check if profile exists
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      // Create profile
      await query(
        `INSERT INTO company_profiles 
         (user_id, company_name, website, contact_name, industry, description) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [req.user.id, companyName, website, contactName, industry, description]
      );
    } else {
      // Update profile
      await query(
        `UPDATE company_profiles 
         SET company_name = $1, website = $2, contact_name = $3, 
             industry = $4, description = $5, updated_at = CURRENT_TIMESTAMP 
         WHERE user_id = $6`,
        [companyName, website, contactName, industry, description, req.user.id]
      );
    }

    res.status(200).json({
      success: true,
      message: "Company profile updated successfully",
    });
  } catch (error) {
    console.error("Update company profile error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};


profile-controller.js