
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    user_type VARCHAR(50) NOT NULL, -- 'student' or 'company'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE company_profiles (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    company_name VARCHAR(255) NOT NULL,
    website VARCHAR(255),
    contact_name VARCHAR(255),
    industry VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);


CREATE TABLE student_profiles (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    dob DATE,
    gender VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE student_education (
    id SERIAL PRIMARY KEY,
    student_id INT NOT NULL UNIQUE,
    current_school VARCHAR(255),
    degree VARCHAR(100),
    major VARCHAR(100),
    gpa DECIMAL(3,2),
    graduation_date DATE,
    previous_education TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student_profiles(id) ON DELETE CASCADE
);

CREATE TABLE student_achievements (
    id SERIAL PRIMARY KEY,
    student_id INT NOT NULL UNIQUE,
    awards TEXT,
    activities TEXT,
    work_experience TEXT,
    skills TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student_profiles(id) ON DELETE CASCADE
);

CREATE TABLE scholarships (
    id SERIAL PRIMARY KEY,
    company_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    open_date DATE NOT NULL,
    deadline DATE NOT NULL,
    recipients_count INT NOT NULL,
    education_level VARCHAR(100),
    min_gpa DECIMAL(3,2),
    fields_of_study VARCHAR(255),
    additional_requirements TEXT,
    required_documents TEXT,
    essay_prompt TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES company_profiles(id) ON DELETE CASCADE
);

CREATE TABLE applications (
    id SERIAL PRIMARY KEY,
    scholarship_id INT NOT NULL,
    student_id INT NOT NULL,
    essay_response TEXT,
    documents_urls TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'started', -- 'started', 'submitted', 'reviewed', etc.
    feedback TEXT,
    submitted_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scholarship_id) REFERENCES scholarships(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES student_profiles(id) ON DELETE CASCADE,
    UNIQUE (scholarship_id, student_id) -- Prevent duplicate applications
);


-- insert scholarships

INSERT INTO scholarships (
    company_id, title, amount, description, open_date, deadline, recipients_count,
    education_level, min_gpa, fields_of_study, additional_requirements,
    required_documents, essay_prompt, status
) VALUES
-- 1
(1, 'Engineering Excellence Scholarship', 5000.00,
 'For outstanding undergraduate engineering students with leadership skills.',
 '2025-05-01', '2025-08-01', 3, 'Undergraduate', 3.5, 'Engineering',
 'Full-time enrollment required.', 'Transcript, Resume, Recommendation Letter',
 'Describe your career goals and how this scholarship will help you.', 'active'),
-- 2
(2, 'Tech Innovators Award', 4000.00,
 'Supporting students in computer science and IT who show innovation.',
 '2025-06-01', '2025-09-01', 2, 'Undergraduate', 3.2, 'Computer Science, IT',
 'Demonstrated project or internship experience.', 'Transcript, Portfolio',
 'Share a project you are proud of and its impact.', 'active'),
-- 3
(3, 'Green Energy Leaders Grant', 6000.00,
 'For students passionate about renewable energy and sustainability.',
 '2025-05-15', '2025-08-15', 4, 'Undergraduate', 3.4, 'Environmental Science, Engineering',
 'Participation in sustainability initiatives.', 'Transcript, Essay',
 'How will you contribute to a sustainable future?', 'active'),
-- 4
(4, 'Healthcare Advancement Scholarship', 5500.00,
 'For students pursuing healthcare technology or medical research.',
 '2025-04-20', '2025-07-20', 2, 'Undergraduate', 3.6, 'Healthcare, Biomedical Engineering',
 'Volunteer or research experience preferred.', 'Transcript, Recommendation Letter',
 'Describe a healthcare challenge you want to solve.', 'active'),
-- 5
(5, 'NextGen Educators Award', 3000.00,
 'For future educators and EdTech innovators.',
 '2025-05-10', '2025-08-10', 3, 'Undergraduate', 3.3, 'Education, EdTech',
 'Interest in educational technology.', 'Transcript, Essay',
 'How will you use technology to improve education?', 'active'),
-- 6
(6, 'BuildRight Construction Grant', 4500.00,
 'For students in civil engineering or construction management.',
 '2025-06-05', '2025-09-05', 2, 'Undergraduate', 3.0, 'Civil Engineering, Construction',
 'Hands-on project experience required.', 'Transcript, Project Portfolio',
 'Describe a construction project you contributed to.', 'active'),
-- 7
(7, 'AeroVision Aerospace Scholarship', 7000.00,
 'For students excelling in aerospace engineering.',
 '2025-05-25', '2025-08-25', 1, 'Undergraduate', 3.7, 'Aerospace Engineering',
 'Participation in aerospace competitions preferred.', 'Transcript, Recommendation Letter',
 'What excites you most about the future of aerospace?', 'active');


-- insert users

INSERT INTO users (email, password_hash, name, user_type) VALUES
('hr@acmeengineering.com', '$2b$10$abcdefghijklmnopqrstuv', 'Acme Engineering', 'company'),
('hr@betatech.com', '$2b$10$abcdefghijklmnopqrstuv', 'Beta Tech Solutions', 'company'),
('hr@greenfuture.com', '$2b$10$abcdefghijklmnopqrstuv', 'Green Future Energy', 'company'),
('hr@medadvance.com', '$2b$10$abcdefghijklmnopqrstuv', 'MedAdvance', 'company'),
('hr@edunext.org', '$2b$10$abcdefghijklmnopqrstuv', 'EduNext', 'company'),
('hr@buildright.com', '$2b$10$abcdefghijklmnopqrstuv', 'BuildRight Construction', 'company'),
('hr@aerovision.com', '$2b$10$abcdefghijklmnopqrstuv', 'AeroVision', 'company');

--  insert company profilers

INSERT INTO company_profiles (user_id, company_name, website, contact_name, industry, description) VALUES
(1, 'Acme Engineering', 'https://acmeengineering.com', 'Jane Doe', 'Engineering', 'Leading provider of innovative engineering solutions for the energy sector.'),
(2, 'Beta Tech Solutions', 'https://betatech.com', 'John Smith', 'Technology', 'Pioneering software and hardware solutions for modern businesses.'),
(3, 'Green Future Energy', 'https://greenfuture.com', 'Emily Green', 'Renewable Energy', 'Committed to sustainable and renewable energy projects worldwide.'),
(4, 'MedAdvance', 'https://medadvance.com', 'Dr. Alan White', 'Healthcare', 'Innovative healthcare technology and medical research.'),
(5, 'EduNext', 'https://edunext.org', 'Sara Lee', 'Education', 'Empowering students and educators with next-generation learning tools.'),
(6, 'BuildRight Construction', 'https://buildright.com', 'Carlos Martinez', 'Construction', 'Quality construction and infrastructure development services.'),
(7, 'AeroVision', 'https://aerovision.com', 'Linda Park', 'Aerospace', 'Advanced aerospace engineering and research.');
