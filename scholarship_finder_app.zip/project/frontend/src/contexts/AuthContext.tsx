import {
  createContext,
  useState,
  useContext,
  useEffect,
  ReactNode,
} from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import axios from "axios";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1";

// Define types
type User = {
  id: number;
  email: string;
  name: string;
  userType: "student" | "company";
  token?: string;
};

type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (credentials: {
    email: string;
    password: string;
  }) => Promise<{ success: boolean; message?: string }>;
  register: (userData: {
    email: string;
    password: string;
    name: string;
    userType: "student" | "company";
  }) => Promise<{ success: boolean; message?: string }>;
  logout: () => void;
};

// Create API client
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Add token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Create context
const AuthContext = createContext<AuthContextType | null>(null);

// Create provider
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Check if user is logged in on initial load
  useEffect(() => {
    const checkUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (token) {
          const res = await apiClient.get("/auth/current-user");
          if (res.data.success) {
            setUser({
              ...res.data.data,
              token,
            });
          } else {
            localStorage.removeItem("token");
          }
        }
      } catch (error) {
        console.error("Error checking user:", error);
        localStorage.removeItem("token");
      } finally {
        setLoading(false);
      }
    };

    checkUser();
  }, []);

  // Login function
  const login = async (credentials: { email: string; password: string }) => {
    try {
      const res = await apiClient.post("/auth/login", credentials);
      if (res.data.success) {
        localStorage.setItem("token", res.data.data.token);
        setUser(res.data.data);
        toast.success("Login successful");
        return { success: true };
      } else {
        return { success: false, message: res.data.message || "Login failed" };
      }
    } catch (error: unknown) {
      console.error("Error logging in:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Login failed",
      };
    }
  };

  // Register function
  const register = async (userData: {
    email: string;
    password: string;
    name: string;
    userType: "student" | "company";
  }) => {
    try {
      const res = await apiClient.post("/auth/register", userData);
      if (res.data.success) {
        localStorage.setItem("token", res.data.data.token);
        setUser(res.data.data);
        toast.success("Registration successful");
        return { success: true };
      } else {
        return {
          success: false,
          message: res.data.message || "Registration failed",
        };
      }
    } catch (error: unknown) {
      return {
        success: false,
        message:
          error instanceof Error
            ? error.message
            : "Registration failed",
      };
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem("token");
    setUser(null);
    toast.info("Logged out successfully");
    navigate("/");
  };

  const value = {
    user,
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
