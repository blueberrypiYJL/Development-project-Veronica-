import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

const ProfilePage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    // If user is student
    studentData: {
      firstName: "",
      lastName: "",
      phone: "",
      dob: "",
      gender: "",
      address: "",
      education: {
        currentSchool: "",
        degree: "",
        major: "",
        gpa: "",
        graduationDate: "",
        previousEducation: "",
      },
      achievements: {
        awards: "",
        activities: "",
        workExperience: "",
        skills: "",
      },
    },
    // If user is company
    companyData: {
      companyName: "",
      website: "",
      contactName: "",
      industry: "",
      description: "",
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      toast.success("Profile updated successfully");
      setLoading(false);

      // Redirect based on user type
      if (user?.userType === "student") {
        navigate("/student/dashboard");
      } else if (user?.userType === "company") {
        navigate("/company/dashboard");
      }
    }, 1000);
  };

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-8">Your Profile</h1>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>Update your basic account details</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium">
                Name
              </label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                disabled
              />
              <p className="text-xs text-muted-foreground">
                Contact support to change your name
              </p>
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-medium">
                Email
              </label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                disabled
              />
              <p className="text-xs text-muted-foreground">
                Contact support to change your email
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground">
              Account information can only be changed by contacting support.
            </p>
          </CardFooter>
        </form>
      </Card>

      {user?.userType === "student" ? (
        <Card>
          <CardHeader>
            <CardTitle>Student Profile</CardTitle>
            <CardDescription>
              Add additional information about yourself to improve your
              scholarship matches
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="firstName" className="text-sm font-medium">
                    First Name
                  </label>
                  <Input
                    id="firstName"
                    name="studentData.firstName"
                    value={formData.studentData.firstName}
                    onChange={handleInputChange}
                    placeholder="John"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="lastName" className="text-sm font-medium">
                    Last Name
                  </label>
                  <Input
                    id="lastName"
                    name="studentData.lastName"
                    value={formData.studentData.lastName}
                    onChange={handleInputChange}
                    placeholder="Doe"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Contact Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">
                      Phone Number
                    </label>
                    <Input
                      id="phone"
                      name="studentData.phone"
                      value={formData.studentData.phone}
                      onChange={handleInputChange}
                      placeholder="(123) 456-7890"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="address" className="text-sm font-medium">
                      Address
                    </label>
                    <Input
                      id="address"
                      name="studentData.address"
                      value={formData.studentData.address}
                      onChange={handleInputChange}
                      placeholder="123 Main St, City, State, ZIP"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-medium">Education Information</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <label
                      htmlFor="currentSchool"
                      className="text-sm font-medium"
                    >
                      Current School
                    </label>
                    <Input
                      id="currentSchool"
                      name="studentData.education.currentSchool"
                      value={formData.studentData.education.currentSchool}
                      onChange={handleInputChange}
                      placeholder="University name"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="degree" className="text-sm font-medium">
                        Degree
                      </label>
                      <Input
                        id="degree"
                        name="studentData.education.degree"
                        value={formData.studentData.education.degree}
                        onChange={handleInputChange}
                        placeholder="Bachelor of Science"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="major" className="text-sm font-medium">
                        Major
                      </label>
                      <Input
                        id="major"
                        name="studentData.education.major"
                        value={formData.studentData.education.major}
                        onChange={handleInputChange}
                        placeholder="Computer Science"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="gpa" className="text-sm font-medium">
                        GPA
                      </label>
                      <Input
                        id="gpa"
                        name="studentData.education.gpa"
                        value={formData.studentData.education.gpa}
                        onChange={handleInputChange}
                        placeholder="3.5"
                      />
                    </div>
                    <div className="space-y-2">
                      <label
                        htmlFor="graduationDate"
                        className="text-sm font-medium"
                      >
                        Expected Graduation
                      </label>
                      <Input
                        id="graduationDate"
                        name="studentData.education.graduationDate"
                        value={formData.studentData.education.graduationDate}
                        onChange={handleInputChange}
                        placeholder="MM/YYYY"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Saving..." : "Save Profile"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Company Profile</CardTitle>
            <CardDescription>
              Provide information about your company and scholarship programs
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="companyName" className="text-sm font-medium">
                  Company Name
                </label>
                <Input
                  id="companyName"
                  name="companyData.companyName"
                  value={formData.companyData.companyName}
                  onChange={handleInputChange}
                  placeholder="Acme Corporation"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="website" className="text-sm font-medium">
                    Website
                  </label>
                  <Input
                    id="website"
                    name="companyData.website"
                    value={formData.companyData.website}
                    onChange={handleInputChange}
                    placeholder="https://www.example.com"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="industry" className="text-sm font-medium">
                    Industry
                  </label>
                  <Input
                    id="industry"
                    name="companyData.industry"
                    value={formData.companyData.industry}
                    onChange={handleInputChange}
                    placeholder="Technology"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="contactName" className="text-sm font-medium">
                  Contact Person
                </label>
                <Input
                  id="contactName"
                  name="companyData.contactName"
                  value={formData.companyData.contactName}
                  onChange={handleInputChange}
                  placeholder="Jane Smith"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="description" className="text-sm font-medium">
                  Company Description
                </label>
                <textarea
                  id="description"
                  name="companyData.description"
                  value={formData.companyData.description}
                  onChange={handleInputChange}
                  placeholder="Tell us about your company and scholarship mission..."
                  className="w-full h-32 p-2 border rounded-md"
                ></textarea>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Saving..." : "Save Profile"}
              </Button>
            </CardFooter>
          </form>
        </Card>
      )}
    </div>
  );
};

export default ProfilePage;
