import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "sonner";
import axios from "axios";
import { useAuth } from "@/contexts/AuthContext";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api/v1";

type Scholarship = {
  id: number;
  title: string;
  amount: number;
  deadline: string;
  status: string;
  open_date: string;
  recipients_count: number;
  created_at: string;
};

const CompanyDashboardPage = () => {
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    const fetchScholarships = async () => {
      try {
        // Set up auth header
        const token = localStorage.getItem("token");
        const config = {
          headers: { Authorization: `Bearer ${token}` },
        };

        const response = await axios.get(
          `${API_URL}/scholarships/company/all`,
          config
        );
        if (response.data.success) {
          setScholarships(response.data.data);
        } else {
          toast.error("Failed to fetch scholarships");
        }
      } catch (error: unknown) {
        console.error("Error fetching scholarships:", error);
        toast.error("An error occurred while fetching scholarships");
      } finally {
        setLoading(false);
      }
    };

    fetchScholarships();
  }, []);

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = {
      year: "numeric",
      month: "long",
      day: "numeric",
    };
    return new Date(dateString).toLocaleDateString("en-US", options);
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800";
      case "draft":
        return "bg-gray-100 text-gray-800";
      case "completed":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Company Dashboard</h1>
        <Button asChild>
          <Link to="/scholarships/create">Create Scholarship</Link>
        </Button>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Company Profile</CardTitle>
          <CardDescription>Manage your company information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="text-muted-foreground mb-1">Company Name</div>
            <div className="font-medium">{user?.name || "Not set"}</div>
          </div>
          <div className="mb-4">
            <div className="text-muted-foreground mb-1">Email</div>
            <div className="font-medium">{user?.email || "Not set"}</div>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline">
            <Link to="/profile">Edit Profile</Link>
          </Button>
        </CardFooter>
      </Card>

      <h2 className="text-2xl font-bold mb-4">Your Scholarships</h2>

      {loading ? (
        <div className="flex justify-center py-8">Loading scholarships...</div>
      ) : scholarships.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              You haven't created any scholarships yet.
            </p>
            <Button asChild>
              <Link to="/scholarships/create">
                Create Your First Scholarship
              </Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {scholarships.map((scholarship) => (
            <Card key={scholarship.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{scholarship.title}</CardTitle>
                    <CardDescription>
                      Created on {formatDate(scholarship.created_at)}
                    </CardDescription>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeClass(
                      scholarship.status
                    )}`}
                  >
                    {scholarship.status.charAt(0).toUpperCase() +
                      scholarship.status.slice(1)}
                  </span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <div className="text-muted-foreground text-sm">Amount</div>
                    <div className="font-medium">
                      {formatAmount(scholarship.amount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-sm">
                      Deadline
                    </div>
                    <div className="font-medium">
                      {formatDate(scholarship.deadline)}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-sm">
                      Recipients
                    </div>
                    <div className="font-medium">
                      {scholarship.recipients_count}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-wrap gap-2">
                <Button asChild variant="outline" size="sm">
                  <Link to={`/scholarships/${scholarship.id}`}>View</Link>
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to={`/scholarships/${scholarship.id}/edit`}>Edit</Link>
                </Button>
                <Button asChild variant="outline" size="sm">
                  <Link to={`/scholarships/${scholarship.id}/applications`}>
                    View Applications
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default CompanyDashboardPage;
