# Scholarship Finder Frontend

This is the frontend for the Scholarship Finder application. It's built with:

- Vite
- React
- TypeScript
- Tailwind CSS
- shadcn/ui
- React Router

## Getting Started

### Prerequisites

- Node.js 18+ and npm/yarn
- Backend API running (see backend directory)

### Installation

1. Clone the repository
2. Navigate to the frontend directory
3. Install dependencies:

```bash
npm install
```

4. Create a `.env` file in the frontend directory with the following content:

```
VITE_API_URL=http://localhost:5000/api/v1
```

### Development

Run the development server:

```bash
npm run dev
```

### Build

Create a production build:

```bash
npm run build
```

### Deployment

Preview the production build:

```bash
npm run preview
```

## Project Structure

```
frontend/
├── public/              # Static files
├── src/
│   ├── components/      # React components
│   │   └── ui/          # shadcn UI components
│   ├── contexts/        # React context providers
│   ├── lib/             # Utility functions
│   ├── pages/           # Page components
│   ├── App.tsx          # Main app component
│   ├── index.css        # Global styles
│   └── main.tsx         # Main entry point
├── .env.example         # Example environment variables
├── index.html           # HTML template
├── package.json         # Dependencies and scripts
├── tailwind.config.js   # Tailwind configuration
├── tsconfig.json        # TypeScript configuration
└── vite.config.ts       # Vite configuration
```
