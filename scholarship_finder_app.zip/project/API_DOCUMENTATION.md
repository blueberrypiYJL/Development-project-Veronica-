# Scholarship Finder API Documentation

## Base URL

```
/api/v1
```

## Authentication

### Register a new user

```
POST /auth/register
```

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe",
  "userType": "student" // or "company"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "userType": "student",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Login

```
POST /auth/login
```

**Request Body:**

```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "userType": "student",
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Get Current User

```
GET /auth/current-user
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "userType": "student"
  }
}
```

## Scholarships

### Get All Scholarships

```
GET /scholarships
```

**Response:**

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": 1,
      "company_id": 1,
      "title": "Engineering Scholarship",
      "amount": 5000.0,
      "description": "Scholarship for engineering students...",
      "open_date": "2023-01-01",
      "deadline": "2023-05-01",
      "recipients_count": 5,
      "education_level": "Undergraduate",
      "min_gpa": 3.5,
      "fields_of_study": "Engineering",
      "additional_requirements": "...",
      "required_documents": "...",
      "essay_prompt": "Describe your career goals...",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z",
      "company_name": "Tech Company Inc."
    }
    // More scholarships...
  ]
}
```

### Get Scholarship by ID

```
GET /scholarships/:id
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "company_id": 1,
    "title": "Engineering Scholarship",
    "amount": 5000.0,
    "description": "Scholarship for engineering students...",
    "open_date": "2023-01-01",
    "deadline": "2023-05-01",
    "recipients_count": 5,
    "education_level": "Undergraduate",
    "min_gpa": 3.5,
    "fields_of_study": "Engineering",
    "additional_requirements": "...",
    "required_documents": "...",
    "essay_prompt": "Describe your career goals...",
    "status": "active",
    "created_at": "2023-01-01T00:00:00.000Z",
    "updated_at": "2023-01-01T00:00:00.000Z",
    "company_name": "Tech Company Inc."
  }
}
```

### Create Scholarship (Company Only)

```
POST /scholarships
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "title": "Engineering Scholarship",
  "amount": 5000,
  "description": "Scholarship for engineering students...",
  "openDate": "2023-01-01",
  "deadline": "2023-05-01",
  "recipientsCount": 5,
  "educationLevel": "Undergraduate",
  "minGpa": 3.5,
  "fieldsOfStudy": "Engineering",
  "additionalRequirements": "...",
  "requiredDocuments": "...",
  "essayPrompt": "Describe your career goals...",
  "status": "active"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Scholarship created successfully",
  "data": {
    "scholarshipId": 1
  }
}
```

### Update Scholarship (Company Only)

```
PUT /scholarships/:id
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "title": "Updated Engineering Scholarship",
  "amount": 6000,
  "description": "Updated description...",
  "openDate": "2023-01-01",
  "deadline": "2023-06-01",
  "recipientsCount": 6,
  "educationLevel": "Undergraduate",
  "minGpa": 3.6,
  "fieldsOfStudy": "Engineering",
  "additionalRequirements": "...",
  "requiredDocuments": "...",
  "essayPrompt": "Updated prompt...",
  "status": "active"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Scholarship updated successfully"
}
```

### Delete Scholarship (Company Only)

```
DELETE /scholarships/:id
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "message": "Scholarship deleted successfully"
}
```

### Get Company Scholarships (Company Only)

```
GET /scholarships/company/all
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": 1,
      "company_id": 1,
      "title": "Engineering Scholarship",
      "amount": 5000.0,
      "description": "Scholarship for engineering students...",
      "open_date": "2023-01-01",
      "deadline": "2023-05-01",
      "recipients_count": 5,
      "education_level": "Undergraduate",
      "min_gpa": 3.5,
      "fields_of_study": "Engineering",
      "additional_requirements": "...",
      "required_documents": "...",
      "essay_prompt": "Describe your career goals...",
      "status": "active",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
    // More scholarships...
  ]
}
```

## Applications

### Start Application (Student Only)

```
POST /applications/start
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "scholarshipId": 1
}
```

**Response:**

```json
{
  "success": true,
  "message": "Application started successfully",
  "data": {
    "applicationId": 1
  }
}
```

### Submit Application (Student Only)

```
POST /applications
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "scholarshipId": 1,
  "essayResponse": "My essay response...",
  "documentsUrls": "url1, url2, url3"
}
```

**Response:**

```json
{
  "success": true,
  "message": "Application submitted successfully",
  "data": {
    "applicationId": 1
  }
}
```

### Get Student Applications (Student Only)

```
GET /applications
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": 1,
      "scholarship_id": 1,
      "student_id": 1,
      "status": "submitted",
      "submitted_at": "2023-01-15T00:00:00.000Z",
      "essay_response": "My essay response...",
      "documents_urls": "url1, url2, url3",
      "feedback": null,
      "created_at": "2023-01-10T00:00:00.000Z",
      "updated_at": "2023-01-15T00:00:00.000Z",
      "title": "Engineering Scholarship",
      "amount": 5000.0,
      "deadline": "2023-05-01",
      "company_name": "Tech Company Inc."
    }
    // More applications...
  ]
}
```

### Get Company Applications (Company Only)

```
GET /applications/company
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": 1,
      "scholarship_id": 1,
      "student_id": 1,
      "status": "submitted",
      "submitted_at": "2023-01-15T00:00:00.000Z",
      "essay_response": "My essay response...",
      "documents_urls": "url1, url2, url3",
      "feedback": null,
      "created_at": "2023-01-10T00:00:00.000Z",
      "updated_at": "2023-01-15T00:00:00.000Z",
      "scholarship_title": "Engineering Scholarship",
      "first_name": "John",
      "last_name": "Doe",
      "student_email": "john.doe@example.com"
    }
    // More applications...
  ]
}
```

### Get Application by ID

```
GET /applications/:id
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response (Student View):**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "scholarship_id": 1,
    "student_id": 1,
    "status": "submitted",
    "submitted_at": "2023-01-15T00:00:00.000Z",
    "essay_response": "My essay response...",
    "documents_urls": "url1, url2, url3",
    "feedback": null,
    "created_at": "2023-01-10T00:00:00.000Z",
    "updated_at": "2023-01-15T00:00:00.000Z",
    "title": "Engineering Scholarship",
    "amount": 5000.0,
    "deadline": "2023-05-01",
    "essay_prompt": "Describe your career goals...",
    "company_name": "Tech Company Inc."
  }
}
```

**Response (Company View):**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "scholarship_id": 1,
    "student_id": 1,
    "status": "submitted",
    "submitted_at": "2023-01-15T00:00:00.000Z",
    "essay_response": "My essay response...",
    "documents_urls": "url1, url2, url3",
    "feedback": null,
    "created_at": "2023-01-10T00:00:00.000Z",
    "updated_at": "2023-01-15T00:00:00.000Z",
    "scholarship_title": "Engineering Scholarship",
    "essay_prompt": "Describe your career goals...",
    "first_name": "John",
    "last_name": "Doe",
    "student_email": "john.doe@example.com"
  }
}
```

### Update Application Status (Company Only)

```
PUT /applications/:id/status
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "status": "under_review", // or "accepted", "rejected"
  "feedback": "Thank you for your application. We are currently reviewing it."
}
```

**Response:**

```json
{
  "success": true,
  "message": "Application status updated successfully"
}
```

## Profiles

### Get Student Profile (Student Only)

```
GET /profiles/student
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "data": {
    "profile": {
      "id": 1,
      "user_id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "phone": "123-456-7890",
      "dob": "2000-01-01",
      "gender": "Male",
      "address": "123 Main St, City, Country",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    },
    "education": {
      "id": 1,
      "student_id": 1,
      "current_school": "University of Example",
      "degree": "Bachelor of Science",
      "major": "Computer Science",
      "gpa": "3.8",
      "graduation_date": "2024-05",
      "previous_education": "High School XYZ",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    },
    "achievements": {
      "id": 1,
      "student_id": 1,
      "awards": "Dean's List, Hackathon Winner",
      "activities": "Student Council, Robotics Club",
      "work_experience": "Internship at Tech Company",
      "skills": "Programming, Problem Solving",
      "created_at": "2023-01-01T00:00:00.000Z",
      "updated_at": "2023-01-01T00:00:00.000Z"
    }
  }
}
```

### Update Student Profile (Student Only)

```
PUT /profiles/student
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "firstName": "John",
  "lastName": "Doe",
  "phone": "123-456-7890",
  "dob": "2000-01-01",
  "gender": "Male",
  "address": "123 Main St, City, Country",
  "education": {
    "currentSchool": "University of Example",
    "degree": "Bachelor of Science",
    "major": "Computer Science",
    "gpa": "3.8",
    "graduationDate": "2024-05",
    "previousEducation": "High School XYZ"
  },
  "achievements": {
    "awards": "Dean's List, Hackathon Winner",
    "activities": "Student Council, Robotics Club",
    "workExperience": "Internship at Tech Company",
    "skills": "Programming, Problem Solving"
  }
}
```

**Response:**

```json
{
  "success": true,
  "message": "Student profile updated successfully"
}
```

### Get Company Profile (Company Only)

```
GET /profiles/company
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Response:**

```json
{
  "success": true,
  "data": {
    "id": 1,
    "user_id": 2,
    "company_name": "Tech Company Inc.",
    "website": "https://techcompany.com",
    "contact_name": "Jane Smith",
    "industry": "Technology",
    "description": "A leading technology company...",
    "created_at": "2023-01-01T00:00:00.000Z",
    "updated_at": "2023-01-01T00:00:00.000Z"
  }
}
```

### Update Company Profile (Company Only)

```
PUT /profiles/company
```

**Headers:**

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

**Request Body:**

```json
{
  "companyName": "Tech Company Inc.",
  "website": "https://techcompany.com",
  "contactName": "Jane Smith",
  "industry": "Technology",
  "description": "A leading technology company..."
}
```

**Response:**

```json
{
  "success": true,
  "message": "Company profile updated successfully"
}
```

## Error Responses

### Validation Error

```json
{
  "success": false,
  "errors": [
    {
      "msg": "Please provide a valid email",
      "param": "email",
      "location": "body"
    }
  ]
}
```

### Authentication Error

```json
{
  "success": false,
  "message": "Not authorized, no token"
}
```

### Resource Not Found

```json
{
  "success": false,
  "message": "Scholarship not found"
}
```

### Server Error

```json
{
  "success": false,
  "message": "Server error"
}
```
