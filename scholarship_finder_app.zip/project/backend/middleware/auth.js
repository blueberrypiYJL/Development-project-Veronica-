const jwt = require("jsonwebtoken");
const { query } = require("../config/db");

// Middleware to protect routes
const protect = async (req, res, next) => {
  let token;

  // Check if token exists in headers
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      // Get token from header
      token = req.headers.authorization.split(" ")[1];

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Get user from token
      const result = await query(
        "SELECT id, email, name, user_type FROM users WHERE id = $1",
        [decoded.id]
      );

      if (result.length === 0) {
        return res.status(401).json({
          success: false,
          message: "Not authorized, user not found",
        });
      }

      // Set user in request
      req.user = result[0];
      next();
    } catch (error) {
      console.error("Auth middleware error:", error);
      return res.status(401).json({
        success: false,
        message: "Not authorized, token failed",
      });
    }
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: "Not authorized, no token",
    });
  }
};

// Middleware to restrict route access by user type
const restrictTo = (...userTypes) => {
  return (req, res, next) => {
    if (!userTypes.includes(req.user.user_type)) {
      return res.status(403).json({
        success: false,
        message: "You do not have permission to perform this action",
      });
    }
    next();
  };
};

module.exports = {
  protect,
  restrictTo,
};
