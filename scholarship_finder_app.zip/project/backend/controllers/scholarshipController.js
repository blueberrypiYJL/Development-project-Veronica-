const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Get all scholarships
// @route   GET /api/v1/scholarships
// @access  Public
exports.getAllScholarships = async (req, res) => {
  try {
    // Get active scholarships with company information
    const scholarships = await query(
      `SELECT s.*, cp.company_name 
       FROM scholarships s
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE s.status = 'active' AND s.deadline >= CURRENT_DATE
       ORDER BY s.deadline ASC`
    );

    res.status(200).json({
      success: true,
      count: scholarships.length,
      data: scholarships,
    });
  } catch (error) {
    console.error("Get all scholarships error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get scholarship by ID
// @route   GET /api/v1/scholarships/:id
// @access  Public
exports.getScholarshipById = async (req, res) => {
  try {
    const scholarships = await query(
      `SELECT s.*, cp.company_name 
       FROM scholarships s
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE s.id = $1`,
      [req.params.id]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    res.status(200).json({
      success: true,
      data: scholarships[0],
    });
  } catch (error) {
    console.error("Get scholarship by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Create scholarship
// @route   POST /api/v1/scholarships
// @access  Private/Company
exports.createScholarship = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Extract data from request body
    const {
      title,
      amount,
      description,
      openDate,
      deadline,
      recipientsCount,
      educationLevel,
      minGpa,
      fieldsOfStudy,
      additionalRequirements,
      requiredDocuments,
      essayPrompt,
      status,
    } = req.body;

    // Insert scholarship
    const result = await query(
      `INSERT INTO scholarships (
        company_id, title, amount, description, open_date, deadline, 
        recipients_count, education_level, min_gpa, fields_of_study, 
        additional_requirements, required_documents, essay_prompt, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14) RETURNING id`,
      [
        companyId,
        title,
        amount,
        description,
        openDate,
        deadline,
        recipientsCount,
        educationLevel,
        minGpa,
        fieldsOfStudy,
        additionalRequirements,
        requiredDocuments,
        essayPrompt,
        status || "draft",
      ]
    );

    const scholarshipId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Scholarship created successfully",
      data: { scholarshipId },
    });
  } catch (error) {
    console.error("Create scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Update scholarship
// @route   PUT /api/v1/scholarships/:id
// @access  Private/Company
exports.updateScholarship = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Check if scholarship exists and belongs to company
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1 AND company_id = $2",
      [req.params.id, companyId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found or not authorized",
      });
    }

    // Extract data from request body
    const {
      title,
      amount,
      description,
      openDate,
      deadline,
      recipientsCount,
      educationLevel,
      minGpa,
      fieldsOfStudy,
      additionalRequirements,
      requiredDocuments,
      essayPrompt,
      status,
    } = req.body;

    // Update scholarship
    await query(
      `UPDATE scholarships SET
        title = $1,
        amount = $2,
        description = $3,
        open_date = $4,
        deadline = $5,
        recipients_count = $6,
        education_level = $7,
        min_gpa = $8,
        fields_of_study = $9,
        additional_requirements = $10,
        required_documents = $11,
        essay_prompt = $12,
        status = $13,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $14 AND company_id = $15`,
      [
        title,
        amount,
        description,
        openDate,
        deadline,
        recipientsCount,
        educationLevel,
        minGpa,
        fieldsOfStudy,
        additionalRequirements,
        requiredDocuments,
        essayPrompt,
        status,
        req.params.id,
        companyId,
      ]
    );

    res.status(200).json({
      success: true,
      message: "Scholarship updated successfully",
    });
  } catch (error) {
    console.error("Update scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Delete scholarship
// @route   DELETE /api/v1/scholarships/:id
// @access  Private/Company
exports.deleteScholarship = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Check if scholarship exists and belongs to company
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1 AND company_id = $2",
      [req.params.id, companyId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found or not authorized",
      });
    }

    // Delete scholarship
    await query("DELETE FROM scholarships WHERE id = $1", [req.params.id]);

    res.status(200).json({
      success: true,
      message: "Scholarship deleted successfully",
    });
  } catch (error) {
    console.error("Delete scholarship error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company scholarships
// @route   GET /api/v1/scholarships/company
// @access  Private/Company
exports.getCompanyScholarships = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Get scholarships
    const scholarships = await query(
      `SELECT * FROM scholarships 
       WHERE company_id = $1 
       ORDER BY created_at DESC`,
      [companyId]
    );

    res.status(200).json({
      success: true,
      count: scholarships.length,
      data: scholarships,
    });
  } catch (error) {
    console.error("Get company scholarships error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};
