const { query } = require("../config/db");
const { validationResult } = require("express-validator");

// @desc    Submit application
// @route   POST /api/v1/applications
// @access  Private/Student
exports.submitApplication = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;
    const { scholarshipId, essayResponse, documentsUrls } = req.body;

    // Check if scholarship exists
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1",
      [scholarshipId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    // Check if already applied
    const existingApplications = await query(
      "SELECT * FROM applications WHERE scholarship_id = $1 AND student_id = $2",
      [scholarshipId, studentId]
    );

    if (existingApplications.length > 0) {
      // If already started, update it
      const existingApp = existingApplications[0];

      await query(
        `UPDATE applications 
        SET essay_response = $1, documents_urls = $2, status = 'submitted', submitted_at = CURRENT_TIMESTAMP 
        WHERE id = $3`,
        [essayResponse, documentsUrls, existingApp.id]
      );

      return res.status(200).json({
        success: true,
        message: "Application submitted successfully",
        data: { applicationId: existingApp.id },
      });
    }

    // Create new application
    const result = await query(
      `INSERT INTO applications 
      (scholarship_id, student_id, essay_response, documents_urls, status, submitted_at) 
      VALUES ($1, $2, $3, $4, 'submitted', CURRENT_TIMESTAMP) RETURNING id`,
      [scholarshipId, studentId, essayResponse, documentsUrls]
    );

    const applicationId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Application submitted successfully",
      data: { applicationId },
    });
  } catch (error) {
    console.error("Submit application error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Start application
// @route   POST /api/v1/applications/start
// @access  Private/Student
exports.startApplication = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;
    const { scholarshipId } = req.body;

    // Check if scholarship exists
    const scholarships = await query(
      "SELECT * FROM scholarships WHERE id = $1",
      [scholarshipId]
    );

    if (scholarships.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Scholarship not found",
      });
    }

    // Check if already applied
    const existingApplications = await query(
      "SELECT * FROM applications WHERE scholarship_id = $1 AND student_id = $2",
      [scholarshipId, studentId]
    );

    if (existingApplications.length > 0) {
      return res.status(400).json({
        success: false,
        message: "You have already started an application for this scholarship",
        data: { applicationId: existingApplications[0].id },
      });
    }

    // Create new application
    const result = await query(
      "INSERT INTO applications (scholarship_id, student_id, status) VALUES ($1, $2, $3) RETURNING id",
      [scholarshipId, studentId, "started"]
    );

    const applicationId = result[0].id;

    res.status(201).json({
      success: true,
      message: "Application started successfully",
      data: { applicationId },
    });
  } catch (error) {
    console.error("Start application error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get student applications
// @route   GET /api/v1/applications
// @access  Private/Student
exports.getStudentApplications = async (req, res) => {
  try {
    // Get student profile
    const studentProfiles = await query(
      "SELECT * FROM student_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (studentProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Student profile not found",
      });
    }

    const studentId = studentProfiles[0].id;

    // Get applications with scholarship and company details
    const applications = await query(
      `SELECT a.*, s.title, s.amount, s.deadline, cp.company_name
       FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       JOIN company_profiles cp ON s.company_id = cp.id
       WHERE a.student_id = $1
       ORDER BY a.created_at DESC`,
      [studentId]
    );

    res.status(200).json({
      success: true,
      count: applications.length,
      data: applications,
    });
  } catch (error) {
    console.error("Get student applications error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get company applications
// @route   GET /api/v1/applications/company
// @access  Private/Company
exports.getCompanyApplications = async (req, res) => {
  try {
    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Get applications for company scholarships
    const applications = await query(
      `SELECT a.*, s.title as scholarship_title, 
              sp.first_name, sp.last_name,
              u.email as student_email
       FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       JOIN student_profiles sp ON a.student_id = sp.id
       JOIN users u ON sp.user_id = u.id
       WHERE s.company_id = $1
       ORDER BY a.submitted_at DESC`,
      [companyId]
    );

    res.status(200).json({
      success: true,
      count: applications.length,
      data: applications,
    });
  } catch (error) {
    console.error("Get company applications error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Get application by ID
// @route   GET /api/v1/applications/:id
// @access  Private
exports.getApplicationById = async (req, res) => {
  try {
    const { id } = req.params;
    let application;

    if (req.user.user_type === "student") {
      // Get student profile
      const studentProfiles = await query(
        "SELECT * FROM student_profiles WHERE user_id = $1",
        [req.user.id]
      );

      if (studentProfiles.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Student profile not found",
        });
      }

      const studentId = studentProfiles[0].id;

      // Get application if it belongs to student
      const applications = await query(
        `SELECT a.*, s.title, s.amount, s.deadline, s.essay_prompt, cp.company_name
         FROM applications a
         JOIN scholarships s ON a.scholarship_id = s.id
         JOIN company_profiles cp ON s.company_id = cp.id
         WHERE a.id = $1 AND a.student_id = $2`,
        [id, studentId]
      );

      if (applications.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Application not found or unauthorized",
        });
      }

      application = applications[0];
    } else if (req.user.user_type === "company") {
      // Get company profile
      const companyProfiles = await query(
        "SELECT * FROM company_profiles WHERE user_id = $1",
        [req.user.id]
      );

      if (companyProfiles.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Company profile not found",
        });
      }

      const companyId = companyProfiles[0].id;

      // Get application if it belongs to company's scholarship
      const applications = await query(
        `SELECT a.*, s.title as scholarship_title, s.essay_prompt,
                sp.first_name, sp.last_name,
                u.email as student_email
         FROM applications a
         JOIN scholarships s ON a.scholarship_id = s.id
         JOIN student_profiles sp ON a.student_id = sp.id
         JOIN users u ON sp.user_id = u.id
         WHERE a.id = $1 AND s.company_id = $2`,
        [id, companyId]
      );

      if (applications.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Application not found or unauthorized",
        });
      }

      application = applications[0];
    } else {
      return res.status(403).json({
        success: false,
        message: "Unauthorized user type",
      });
    }

    res.status(200).json({
      success: true,
      data: application,
    });
  } catch (error) {
    console.error("Get application by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

// @desc    Update application status (for companies)
// @route   PUT /api/v1/applications/:id/status
// @access  Private/Company
exports.updateApplicationStatus = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array(),
    });
  }

  try {
    const { id } = req.params;
    const { status, feedback } = req.body;

    // Get company profile
    const companyProfiles = await query(
      "SELECT * FROM company_profiles WHERE user_id = $1",
      [req.user.id]
    );

    if (companyProfiles.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Company profile not found",
      });
    }

    const companyId = companyProfiles[0].id;

    // Verify application belongs to company's scholarship
    const applications = await query(
      `SELECT a.* FROM applications a
       JOIN scholarships s ON a.scholarship_id = s.id
       WHERE a.id = $1 AND s.company_id = $2`,
      [id, companyId]
    );

    if (applications.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Application not found or unauthorized",
      });
    }

    // Update application status
    await query(
      "UPDATE applications SET status = $1, feedback = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3",
      [status, feedback, id]
    );

    res.status(200).json({
      success: true,
      message: "Application status updated successfully",
    });
  } catch (error) {
    console.error("Update application status error:", error);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};
