const express = require("express");
const { body } = require("express-validator");
const scholarshipController = require("../controllers/scholarshipController");
const { protect, restrictTo } = require("../middleware/auth");

const router = express.Router();

// Public routes
router.get("/", scholarshipController.getAllScholarships);
router.get("/:id", scholarshipController.getScholarshipById);

// Protected company routes
router.get(
  "/company/all",
  protect,
  restrictTo("company"),
  scholarshipController.getCompanyScholarships
);

router.post(
  "/",
  protect,
  restrictTo("company"),
  [
    body("title").notEmpty().withMessage("Title is required"),
    body("amount").isNumeric().withMessage("Amount must be a number"),
    body("description").notEmpty().withMessage("Description is required"),
    body("openDate").isDate().withMessage("Open date must be a valid date"),
    body("deadline").isDate().withMessage("Deadline must be a valid date"),
    body("recipientsCount")
      .isInt()
      .withMessage("Recipients count must be an integer"),
  ],
  scholarshipController.createScholarship
);

router.put(
  "/:id",
  protect,
  restrictTo("company"),
  [
    body("title").notEmpty().withMessage("Title is required"),
    body("amount").isNumeric().withMessage("Amount must be a number"),
    body("description").notEmpty().withMessage("Description is required"),
    body("openDate").isDate().withMessage("Open date must be a valid date"),
    body("deadline").isDate().withMessage("Deadline must be a valid date"),
    body("recipientsCount")
      .isInt()
      .withMessage("Recipients count must be an integer"),
  ],
  scholarshipController.updateScholarship
);

router.delete(
  "/:id",
  protect,
  restrictTo("company"),
  scholarshipController.deleteScholarship
);

module.exports = router;
